
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, Building } from "lucide-react";

export default function ApplicationFilters({ filters, onFiltersChange, applications, agents, currentAgent, showAgentFilter = false, isUniversityView = false }) {
  const uniquePrograms = [...new Set(applications.map(app => app.program_applied))].filter(Boolean);

  const handleFilterChange = (key, value) => {
    onFiltersChange(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Card className="neumorphic rounded-3xl">
      <CardContent className="p-6">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-indigo-600" />
            <span className="font-medium text-neumorphic">Filters:</span>
          </div>
          
          <div className="flex flex-wrap gap-4">
            {showAgentFilter && (
              <Select value={filters.agent} onValueChange={(value) => handleFilterChange('agent', value)}>
                <SelectTrigger className="neumorphic-inset rounded-xl border-0 bg-gray-200 w-48">
                  <SelectValue placeholder="Agent" />
                </SelectTrigger>
                <SelectContent className="neumorphic rounded-2xl border-0">
                  {isUniversityView ? (
                    <>
                      <SelectItem value="all">All Agents</SelectItem>
                      {agents?.map(agent => (
                        <SelectItem key={agent.id} value={agent.id}>{agent.company_name}</SelectItem>
                      ))}
                    </>
                  ) : (
                    <SelectItem value="current">
                      <div className="flex items-center gap-2">
                        <Building className="w-4 h-4" />
                        My Applications
                      </div>
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            )}

            <Select value={filters.status} onValueChange={(value) => handleFilterChange('status', value)}>
              <SelectTrigger className="neumorphic-inset rounded-xl border-0 bg-gray-200 w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent className="neumorphic rounded-2xl border-0">
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="submitted">Submitted</SelectItem>
                <SelectItem value="under_review">Under Review</SelectItem>
                <SelectItem value="additional_docs_required">Docs Required</SelectItem>
                <SelectItem value="conditional_offer">Conditional Offer</SelectItem>
                <SelectItem value="unconditional_offer">Unconditional Offer</SelectItem>
                <SelectItem value="offer_accepted">Offer Accepted</SelectItem>
                <SelectItem value="approved">Approved (Legacy)</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="visa_rejected">Visa Rejected</SelectItem>
                <SelectItem value="enrolled">Enrolled</SelectItem>
                <SelectItem value="withdrawn">Withdrawn</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.program} onValueChange={(value) => handleFilterChange('program', value)}>
              <SelectTrigger className="neumorphic-inset rounded-xl border-0 bg-gray-200 w-48">
                <SelectValue placeholder="Program" />
              </SelectTrigger>
              <SelectContent className="neumorphic rounded-2xl border-0">
                <SelectItem value="all">All Programs</SelectItem>
                {uniquePrograms.map((program) => (
                  <SelectItem key={program} value={program}>{program}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {!isUniversityView && filters.agent === 'current' && currentAgent && (
          <div className="mt-4 p-3 bg-indigo-50 rounded-xl border border-indigo-200">
            <div className="flex items-center gap-2 text-sm text-indigo-800">
              <Building className="w-4 h-4" />
              <span>Filtered to show applications from: <strong>{currentAgent.company_name}</strong></span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
