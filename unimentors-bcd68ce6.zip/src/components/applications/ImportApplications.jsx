import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, Download, FileSpreadsheet, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { Application } from '@/api/entities';
import { UploadFile, ExtractDataFromUploadedFile } from '@/api/integrations';

const SAMPLE_DATA = [
  {
    student_name: "John Smith",
    student_email: "john.smith@email.com", 
    student_phone: "+1-555-0123",
    nationality: "United States",
    program_applied: "B.Sc. Computer Science",
    program_category: "STEM",
    application_type: "Undergraduate",
    campus: "Main Campus",
    intake_date: "2024-09-01",
    notes: "Strong academic background in mathematics"
  },
  {
    student_name: "Maria Garcia",
    student_email: "maria.garcia@email.com",
    student_phone: "+34-600-123456", 
    nationality: "Spain",
    program_applied: "MBA",
    program_category: "Business & Management",
    application_type: "Graduate", 
    campus: "Downtown Campus",
    intake_date: "2024-01-15",
    notes: "5 years experience in marketing"
  },
  {
    student_name: "Li Wei",
    student_email: "li.wei@email.com",
    student_phone: "+86-138-0013-8000",
    nationality: "China", 
    program_applied: "M.Eng. Electrical",
    program_category: "STEM",
    application_type: "Graduate",
    campus: "Main Campus", 
    intake_date: "2024-09-01",
    notes: "Research interest in renewable energy"
  }
];

const EXPECTED_COLUMNS = [
  { key: 'student_name', label: 'Student Name', required: true },
  { key: 'student_email', label: 'Student Email', required: true },
  { key: 'student_phone', label: 'Student Phone', required: false },
  { key: 'nationality', label: 'Nationality', required: false },
  { key: 'program_applied', label: 'Program Applied', required: true },
  { key: 'program_category', label: 'Program Category', required: false },
  { key: 'application_type', label: 'Application Type', required: false },
  { key: 'campus', label: 'Campus', required: false },
  { key: 'intake_date', label: 'Intake Date (YYYY-MM-DD)', required: false },
  { key: 'notes', label: 'Notes', required: false }
];

export default function ImportApplications({ currentAgent, onImportComplete }) {
  const [file, setFile] = useState(null);
  const [importing, setImporting] = useState(false);
  const [results, setResults] = useState(null);
  const [downloadingTemplate, setDownloadingTemplate] = useState(false);

  const downloadTemplate = async () => {
    setDownloadingTemplate(true);
    try {
      // Convert sample data to CSV format
      const headers = EXPECTED_COLUMNS.map(col => col.label).join(',');
      const rows = SAMPLE_DATA.map(row => 
        EXPECTED_COLUMNS.map(col => {
          const value = row[col.key] || '';
          // Wrap in quotes if contains comma
          return value.includes(',') ? `"${value}"` : value;
        }).join(',')
      );
      
      const csvContent = [headers, ...rows].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'application_import_template.csv';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error creating template:', error);
      alert('Error creating template. Please try again.');
    }
    setDownloadingTemplate(false);
  };

  const handleFileUpload = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setResults(null);
    }
  };

  const processImport = async () => {
    if (!file || !currentAgent) return;
    
    setImporting(true);
    setResults(null);
    
    try {
      // Upload file first
      const { file_url } = await UploadFile({ file });
      
      // Define the JSON schema for extraction
      const schema = {
        type: "object",
        properties: {
          applications: {
            type: "array",
            items: {
              type: "object",
              properties: {
                student_name: { type: "string" },
                student_email: { type: "string" },
                student_phone: { type: "string" },
                nationality: { type: "string" },
                program_applied: { type: "string" },
                program_category: { type: "string" },
                application_type: { type: "string" },
                campus: { type: "string" },
                intake_date: { type: "string" },
                notes: { type: "string" }
              },
              required: ["student_name", "student_email", "program_applied"]
            }
          }
        }
      };
      
      // Extract data from uploaded file
      const extractionResult = await ExtractDataFromUploadedFile({
        file_url,
        json_schema: schema
      });
      
      if (extractionResult.status === 'error') {
        setResults({
          success: false,
          error: extractionResult.details,
          imported: 0,
          failed: 0
        });
        return;
      }
      
      const applications = extractionResult.output?.applications || [];
      
      if (applications.length === 0) {
        setResults({
          success: false,
          error: 'No valid applications found in the file',
          imported: 0,
          failed: 0
        });
        return;
      }
      
      // Process each application
      let imported = 0;
      let failed = 0;
      const errors = [];
      
      for (const appData of applications) {
        try {
          // Validate required fields
          if (!appData.student_name || !appData.student_email || !appData.program_applied) {
            failed++;
            errors.push(`Missing required fields for ${appData.student_name || 'Unknown Student'}`);
            continue;
          }
          
          // Prepare application data
          const applicationToCreate = {
            agent_id: currentAgent.id,
            student_name: appData.student_name,
            student_email: appData.student_email,
            student_phone: appData.student_phone || '',
            nationality: appData.nationality || '',
            program_applied: appData.program_applied,
            program_category: appData.program_category || '',
            application_type: appData.application_type || 'Undergraduate',
            campus: appData.campus || 'Main Campus',
            intake_date: appData.intake_date || '',
            notes: appData.notes || '',
            status: 'submitted',
            submission_date: new Date().toISOString().split('T')[0],
            last_updated: new Date().toISOString(),
            commission_eligible: true
          };
          
          await Application.create(applicationToCreate);
          imported++;
        } catch (error) {
          failed++;
          errors.push(`Failed to import ${appData.student_name}: ${error.message}`);
        }
      }
      
      setResults({
        success: imported > 0,
        imported,
        failed,
        errors: errors.slice(0, 10), // Show first 10 errors
        totalErrors: errors.length
      });
      
      if (imported > 0 && onImportComplete) {
        onImportComplete();
      }
      
    } catch (error) {
      console.error('Import error:', error);
      setResults({
        success: false,
        error: 'Failed to process the file. Please check the format and try again.',
        imported: 0,
        failed: 0
      });
    }
    
    setImporting(false);
  };

  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <Upload className="w-6 h-6 text-indigo-600" />
          Import Applications from Excel
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Template Download */}
        <div className="neumorphic-inset rounded-2xl p-4">
          <h3 className="font-semibold text-neumorphic mb-3">Step 1: Download Template</h3>
          <p className="text-sm text-gray-600 mb-4">
            Download our sample Excel template with the correct format and terminology used in this portal.
          </p>
          <Button
            onClick={downloadTemplate}
            disabled={downloadingTemplate}
            className="neumorphic rounded-xl flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            {downloadingTemplate ? 'Creating Template...' : 'Download Sample Template'}
          </Button>
        </div>

        {/* Required Columns Info */}
        <div className="neumorphic-inset rounded-2xl p-4">
          <h3 className="font-semibold text-neumorphic mb-3">Required Columns</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
            {EXPECTED_COLUMNS.map(col => (
              <div key={col.key} className="flex items-center gap-2">
                {col.required ? (
                  <span className="text-red-500">*</span>
                ) : (
                  <span className="text-gray-400">○</span>
                )}
                <span className={col.required ? 'font-medium' : 'text-gray-600'}>
                  {col.label}
                </span>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-2">* Required fields</p>
        </div>

        {/* File Upload */}
        <div className="neumorphic-inset rounded-2xl p-4">
          <h3 className="font-semibold text-neumorphic mb-3">Step 2: Upload Your File</h3>
          <div className="space-y-4">
            <div>
              <Label className="text-neumorphic font-medium">Select Excel/CSV File</Label>
              <Input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileUpload}
                className="neumorphic-inset rounded-xl border-0 bg-gray-200 mt-2"
              />
            </div>
            
            {file && (
              <div className="flex items-center gap-2 text-sm text-green-600">
                <FileSpreadsheet className="w-4 h-4" />
                <span>{file.name} selected</span>
              </div>
            )}
            
            <Button
              onClick={processImport}
              disabled={!file || importing || !currentAgent}
              className="neumorphic rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white"
            >
              {importing ? 'Importing...' : 'Import Applications'}
            </Button>
          </div>
        </div>

        {/* Results */}
        {results && (
          <div className="space-y-4">
            <Alert className={`${results.success ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'} neumorphic-inset rounded-2xl`}>
              <div className="flex items-center gap-2">
                {results.success ? (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-600" />
                )}
                <AlertDescription>
                  <div className="space-y-2">
                    <p className="font-semibold">
                      Import {results.success ? 'Completed' : 'Failed'}
                    </p>
                    <div className="text-sm">
                      <p>✅ Successfully imported: {results.imported} applications</p>
                      {results.failed > 0 && (
                        <p>❌ Failed to import: {results.failed} applications</p>
                      )}
                    </div>
                  </div>
                </AlertDescription>
              </div>
            </Alert>
            
            {results.errors && results.errors.length > 0 && (
              <div className="neumorphic-inset rounded-2xl p-4">
                <h4 className="font-semibold text-neumorphic mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-orange-500" />
                  Import Errors {results.totalErrors > 10 && `(showing first 10 of ${results.totalErrors})`}
                </h4>
                <div className="text-sm text-gray-600 space-y-1 max-h-32 overflow-y-auto">
                  {results.errors.map((error, index) => (
                    <p key={index}>• {error}</p>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}