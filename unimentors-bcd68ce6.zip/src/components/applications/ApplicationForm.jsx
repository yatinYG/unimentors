import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from 'date-fns';
import { Calendar as CalendarIcon } from "lucide-react";

// Consistent terminology data - matches exactly with import template
const PROGRAMS = [
  'B.Sc. Computer Science', 'M.Sc. Data Science', 'BBA', 'MBA', 
  'B.Eng. Mechanical', 'M.Eng. Electrical', 'B.A. History', 'M.A. Literature', 
  'MBBS', 'B.Sc. Nursing', 'B.A. Sociology', 'M.A. Political Science'
];

const PROGRAM_CATEGORIES = ["STEM", "Business & Management", "Arts & Humanities", "Health Sciences", "Social Sciences"];
const APPLICATION_TYPES = ["Undergraduate", "Graduate", "Doctoral", "Certificate"];
const CAMPUSES = ["Main Campus", "Downtown Campus", "Online", "International Campus"];

export default function ApplicationForm({ application, onSubmit, onCancel, currentAgent }) {
  const [formData, setFormData] = useState(application || {
    student_name: '',
    student_email: '',
    student_phone: '',
    nationality: '',
    program_applied: '',
    program_category: '',
    application_type: 'Undergraduate',
    campus: 'Main Campus',
    intake_date: '',
    notes: ''
  });

  const [intakeDate, setIntakeDate] = useState(
    application?.intake_date ? new Date(application.intake_date) : null
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    const submissionData = {
      ...formData,
      intake_date: intakeDate ? format(intakeDate, 'yyyy-MM-dd') : ''
    };
    onSubmit(submissionData);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Student Information */}
      <div className="neumorphic-inset rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-neumorphic mb-4">Student Information</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Student Name *</Label>
            <Input
              value={formData.student_name}
              onChange={(e) => handleInputChange('student_name', e.target.value)}
              className="neumorphic-inset rounded-xl border-0 bg-gray-200"
              required
            />
          </div>
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Student Email *</Label>
            <Input
              type="email"
              value={formData.student_email}
              onChange={(e) => handleInputChange('student_email', e.target.value)}
              className="neumorphic-inset rounded-xl border-0 bg-gray-200"
              required
            />
          </div>
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Student Phone</Label>
            <Input
              value={formData.student_phone}
              onChange={(e) => handleInputChange('student_phone', e.target.value)}
              className="neumorphic-inset rounded-xl border-0 bg-gray-200"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Nationality</Label>
            <Input
              value={formData.nationality}
              onChange={(e) => handleInputChange('nationality', e.target.value)}
              className="neumorphic-inset rounded-xl border-0 bg-gray-200"
              placeholder="e.g. United States, China, India"
            />
          </div>
        </div>
      </div>

      {/* Program Information */}
      <div className="neumorphic-inset rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-neumorphic mb-4">Program Information</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Program Applied *</Label>
            <Select value={formData.program_applied} onValueChange={(value) => handleInputChange('program_applied', value)}>
              <SelectTrigger className="neumorphic-inset rounded-xl border-0 bg-gray-200">
                <SelectValue placeholder="Select program" />
              </SelectTrigger>
              <SelectContent className="neumorphic rounded-2xl border-0">
                {PROGRAMS.map(program => (
                  <SelectItem key={program} value={program}>{program}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Program Category</Label>
            <Select value={formData.program_category} onValueChange={(value) => handleInputChange('program_category', value)}>
              <SelectTrigger className="neumorphic-inset rounded-xl border-0 bg-gray-200">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="neumorphic rounded-2xl border-0">
                {PROGRAM_CATEGORIES.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Application Type</Label>
            <Select value={formData.application_type} onValueChange={(value) => handleInputChange('application_type', value)}>
              <SelectTrigger className="neumorphic-inset rounded-xl border-0 bg-gray-200">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent className="neumorphic rounded-2xl border-0">
                {APPLICATION_TYPES.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Campus</Label>
            <Select value={formData.campus} onValueChange={(value) => handleInputChange('campus', value)}>
              <SelectTrigger className="neumorphic-inset rounded-xl border-0 bg-gray-200">
                <SelectValue placeholder="Select campus" />
              </SelectTrigger>
              <SelectContent className="neumorphic rounded-2xl border-0">
                {CAMPUSES.map(campus => (
                  <SelectItem key={campus} value={campus}>{campus}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label className="text-neumorphic font-medium">Intake Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="neumorphic-inset rounded-xl border-0 bg-gray-200 w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {intakeDate ? format(intakeDate, 'PPP') : 'Select intake date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 neumorphic rounded-2xl border-0">
                <Calendar
                  mode="single"
                  selected={intakeDate}
                  onSelect={setIntakeDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>

      {/* Additional Information */}
      <div className="neumorphic-inset rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-neumorphic mb-4">Additional Information</h3>
        <div className="space-y-2">
          <Label className="text-neumorphic font-medium">Notes</Label>
          <Textarea
            value={formData.notes}
            onChange={(e) => handleInputChange('notes', e.target.value)}
            className="neumorphic-inset rounded-xl border-0 bg-gray-200"
            rows={3}
            placeholder="Any additional information or requirements..."
          />
        </div>
      </div>

      {/* Form Actions */}
      <div className="flex justify-end gap-4">
        <Button
          type="button"
          onClick={onCancel}
          className="neumorphic rounded-xl px-6 py-3 text-neumorphic"
        >
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button
          type="submit"
          className="neumorphic rounded-xl px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white"
        >
          <Save className="w-4 h-4 mr-2" />
          {application ? 'Update Application' : 'Submit Application'}
        </Button>
      </div>
    </form>
  );
}