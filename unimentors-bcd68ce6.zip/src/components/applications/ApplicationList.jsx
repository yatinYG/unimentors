
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Edit, FileText, Clock, CheckCircle, XCircle, AlertCircle, User, Building, ThumbsUp, UserCheck, ShieldAlert, LogOut, HelpCircle } from "lucide-react";
import { Agent } from '@/api/entities';

const statusConfig = {
  submitted: { icon: Clock, color: 'bg-yellow-100 text-yellow-800', label: 'Submitted' },
  under_review: { icon: AlertCircle, color: 'bg-blue-100 text-blue-800', label: 'Under Review' },
  additional_docs_required: { icon: HelpCircle, color: 'bg-orange-100 text-orange-800', label: 'Docs Required' },
  conditional_offer: { icon: HelpCircle, color: 'bg-cyan-100 text-cyan-800', label: 'Conditional Offer' },
  unconditional_offer: { icon: ThumbsUp, color: 'bg-teal-100 text-teal-800', label: 'Offer' },
  offer_accepted: { icon: UserCheck, color: 'bg-indigo-100 text-indigo-800', label: 'Offer Accepted' },
  approved: { icon: CheckCircle, color: 'bg-green-100 text-green-800', label: 'Approved' },
  rejected: { icon: XCircle, color: 'bg-red-100 text-red-800', label: 'Rejected' },
  visa_rejected: { icon: ShieldAlert, color: 'bg-red-200 text-red-900', label: 'Visa Rejected' },
  enrolled: { icon: CheckCircle, color: 'bg-purple-100 text-purple-800', label: 'Enrolled' },
  withdrawn: { icon: LogOut, color: 'bg-gray-200 text-gray-800', label: 'Withdrawn' }
};

const ApplicationItem = ({ application, onEdit, currentAgent, isUniversityView, agentName }) => {
    const statusInfo = statusConfig[application.status] || statusConfig.submitted;
    const StatusIcon = statusInfo.icon;
    const canEdit = isUniversityView || application.agent_id === currentAgent?.id;

    return (
        <div className="p-6 neumorphic-inset rounded-2xl hover:shadow-lg transition-all duration-300">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 neumorphic rounded-xl flex items-center justify-center">
                        <User className="w-6 h-6 text-indigo-600" />
                    </div>
                    <div>
                        <h3 className="font-semibold text-lg text-neumorphic">{application.student_name}</h3>
                        <p className="text-gray-600 font-medium">{application.program_applied}</p>
                        <p className="text-sm text-gray-500">{application.student_email}</p>
                        <div className="flex items-center gap-4 mt-1">
                            <p className="text-xs text-gray-400">Submitted: {format(new Date(application.created_date), 'MMM d, yyyy')}</p>
                            {isUniversityView ? (
                                <Badge variant="outline" className="text-xs px-2 py-0 bg-gray-100 border-gray-300">Agent: {agentName}</Badge>
                            ) : (
                                application.agent_id === currentAgent?.id && <Badge variant="outline" className="text-xs px-2 py-0 bg-indigo-50 text-indigo-600 border-indigo-200">Your Application</Badge>
                            )}
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <Badge className={`${statusInfo.color} border-0 rounded-xl px-3 py-1 font-medium`}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {statusInfo.label}
                    </Badge>
                    {onEdit && (
                        <Button onClick={() => onEdit(application)} className="neumorphic rounded-xl p-2 hover:shadow-lg" size="sm" disabled={!canEdit} title={!canEdit ? "Cannot edit this application" : "Edit application"}>
                            <Edit className="w-4 h-4" />
                        </Button>
                    )}
                </div>
            </div>
            {application.notes && <div className="mt-4 p-3 bg-gray-100 rounded-xl"><p className="text-sm text-gray-600">{application.notes}</p></div>}
        </div>
    );
};

export default function ApplicationList({ applications, onEdit, isLoading, currentAgent, isUniversityView = false }) {
  const [agentMap, setAgentMap] = useState({});

  useEffect(() => {
    if (isUniversityView && applications.length > 0) {
      const fetchAgents = async () => {
        const agentIds = [...new Set(applications.map(app => app.agent_id))];
        if(agentIds.length > 0) {
            try {
                const agents = await Agent.list();
                const map = agents.reduce((acc, agent) => {
                    acc[agent.id] = agent.company_name;
                    return acc;
                }, {});
                setAgentMap(map);
            } catch (error) {
                console.error("Failed to fetch agents:", error);
            }
        }
      };
      fetchAgents();
    }
  }, [applications, isUniversityView]);
  
  if (isLoading) {
      return (
          <Card className="neumorphic rounded-3xl">
              <CardHeader><Skeleton className="h-6 w-1/2" /></CardHeader>
              <CardContent className="space-y-4">
                  {Array(3).fill(0).map((_, i) => (
                      <div key={i} className="p-6 neumorphic-inset rounded-2xl">
                          <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                  <Skeleton className="w-12 h-12 rounded-xl" />
                                  <div>
                                      <Skeleton className="h-5 w-32 mb-2" />
                                      <Skeleton className="h-4 w-48" />
                                  </div>
                              </div>
                              <Skeleton className="h-8 w-24 rounded-xl" />
                          </div>
                      </div>
                  ))}
              </CardContent>
          </Card>
      );
  }

  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-neumorphic">Applications ({applications.length})</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {applications.map((application) => (
            <ApplicationItem 
                key={application.id}
                application={application}
                onEdit={onEdit}
                currentAgent={currentAgent}
                isUniversityView={isUniversityView}
                agentName={agentMap[application.agent_id] || 'N/A'}
            />
          ))}
          {applications.length === 0 && (
              <div className="text-center py-16 text-gray-500">
                  <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">No applications found.</p>
                  <p className="text-sm">Try adjusting your filters or creating a new application.</p>
              </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
