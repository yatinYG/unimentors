import React, { useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { User, CheckSquare, XSquare, TrendingUp } from 'lucide-react';

export default function AgentPerformanceAnalytics({ applications, agents }) {
    const performanceData = useMemo(() => {
        if (!agents.length) return [];
        return agents.map(agent => {
            const agentApps = applications.filter(app => app.agent_id === agent.id);
            const enrolledCount = agentApps.filter(app => app.status === 'enrolled').length;
            const visaRejectedCount = agentApps.filter(app => app.status === 'visa_rejected').length;
            const submissionCount = agentApps.length;
            const conversionRate = submissionCount > 0 ? (enrolledCount / submissionCount) * 100 : 0;

            return {
                id: agent.id,
                name: agent.company_name,
                submissions: submissionCount,
                enrollments: enrolledCount,
                visaRejections: visaRejectedCount,
                conversionRate: conversionRate.toFixed(1) + '%',
            };
        }).sort((a, b) => b.enrollments - a.enrollments);
    }, [applications, agents]);

    return (
        <Card className="neumorphic-inset rounded-2xl">
            <CardHeader>
                <CardTitle className="text-lg font-semibold text-neumorphic">Agent Performance Comparison</CardTitle>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead><div className="flex items-center gap-2"><User size={16}/>Agent Name</div></TableHead>
                            <TableHead><div className="flex items-center gap-2"><CheckSquare size={16}/>Submissions</div></TableHead>
                            <TableHead><div className="flex items-center gap-2"><CheckSquare size={16}/>Enrollments</div></TableHead>
                            <TableHead><div className="flex items-center gap-2"><XSquare size={16}/>Visa Rejections</div></TableHead>
                            <TableHead><div className="flex items-center gap-2"><TrendingUp size={16}/>Conversion Rate</div></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {performanceData.map(agent => (
                            <TableRow key={agent.id}>
                                <TableCell className="font-medium">{agent.name}</TableCell>
                                <TableCell>{agent.submissions}</TableCell>
                                <TableCell>{agent.enrollments}</TableCell>
                                <TableCell>{agent.visaRejections}</TableCell>
                                <TableCell>{agent.conversionRate}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}