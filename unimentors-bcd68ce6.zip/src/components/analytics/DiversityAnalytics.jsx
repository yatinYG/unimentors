import React, { useState, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

// Consistent Terminology Data
const PROGRAM_CATEGORIES = ["STEM", "Business & Management", "Arts & Humanities", "Health Sciences", "Social Sciences"];
const PROGRAM_LEVELS = ["Undergraduate", "Graduate", "Doctoral", "Certificate"];
const CAMPUSES = ["Main Campus", "Downtown Campus", "Online", "International Campus"];

const AnalyticsCard = ({ title, data }) => (
    <Card className="neumorphic-inset rounded-2xl">
        <CardHeader><CardTitle className="text-base font-semibold text-neumorphic">{title}</CardTitle></CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Category</TableHead>
                        <TableHead className="text-right">Count</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {data.map(item => (
                        <TableRow key={item.name}>
                            <TableCell>{item.name}</TableCell>
                            <TableCell className="text-right">{item.count}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
    </Card>
);

export default function DiversityAnalytics({ applications, agents }) {
    const [filters, setFilters] = useState({
        agent: 'all',
        nationality: 'all',
        program: 'all',
        campus: 'all',
        intake: 'all'
    });

    const filterOptions = useMemo(() => {
        const nationalities = [...new Set(applications.map(app => app.nationality).filter(Boolean))];
        const programs = [...new Set(applications.map(app => app.program_applied).filter(Boolean))];
        const intakes = [...new Set(applications.map(app => app.intake_date).filter(Boolean))];
        return { nationalities, programs, intakes };
    }, [applications]);
    
    const filteredApps = useMemo(() => {
        return applications.filter(app => {
            return (filters.agent === 'all' || app.agent_id === filters.agent) &&
                   (filters.nationality === 'all' || app.nationality === filters.nationality) &&
                   (filters.program === 'all' || app.program_applied === filters.program) &&
                   (filters.campus === 'all' || app.campus === filters.campus) &&
                   (filters.intake === 'all' || app.intake_date === filters.intake);
        });
    }, [applications, filters]);

    const diversityData = useMemo(() => {
        const groupAndCount = (key) => {
            const counts = filteredApps.reduce((acc, app) => {
                const value = app[key];
                if (value) {
                    acc[value] = (acc[value] || 0) + 1;
                }
                return acc;
            }, {});
            return Object.entries(counts).map(([name, count]) => ({ name, count })).sort((a,b) => b.count - a.count);
        };
        return {
            byNationality: groupAndCount('nationality'),
            byProgramCategory: groupAndCount('program_category'),
            byProgramLevel: groupAndCount('application_type'),
            byProgramName: groupAndCount('program_applied'),
        };
    }, [filteredApps]);

    const handleFilterChange = (key, value) => {
        setFilters(prev => ({ ...prev, [key]: value }));
    };

    return (
        <div className="space-y-6">
            <Card className="neumorphic-inset rounded-2xl p-4">
                <div className="flex flex-wrap gap-4">
                    <Select value={filters.agent} onValueChange={(v) => handleFilterChange('agent', v)}>
                        <SelectTrigger className="w-48 neumorphic-inset"><SelectValue placeholder="Agent" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Agents</SelectItem>
                            {agents.map(a => <SelectItem key={a.id} value={a.id}>{a.company_name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Select value={filters.nationality} onValueChange={(v) => handleFilterChange('nationality', v)}>
                        <SelectTrigger className="w-48 neumorphic-inset"><SelectValue placeholder="Nationality" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Nationalities</SelectItem>
                            {filterOptions.nationalities.map(n => <SelectItem key={n} value={n}>{n}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Select value={filters.program} onValueChange={(v) => handleFilterChange('program', v)}>
                        <SelectTrigger className="w-48 neumorphic-inset"><SelectValue placeholder="Program" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Programs</SelectItem>
                            {filterOptions.programs.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Select value={filters.campus} onValueChange={(v) => handleFilterChange('campus', v)}>
                        <SelectTrigger className="w-48 neumorphic-inset"><SelectValue placeholder="Campus" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Campuses</SelectItem>
                            {CAMPUSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Select value={filters.intake} onValueChange={(v) => handleFilterChange('intake', v)}>
                        <SelectTrigger className="w-48 neumorphic-inset"><SelectValue placeholder="Intake" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Intakes</SelectItem>
                            {filterOptions.intakes.map(i => <SelectItem key={i} value={i}>{new Date(i).toLocaleDateString()}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <AnalyticsCard title="By Nationality" data={diversityData.byNationality} />
                <AnalyticsCard title="By Program Category" data={diversityData.byProgramCategory} />
                <AnalyticsCard title="By Program Level" data={diversityData.byProgramLevel} />
                <AnalyticsCard title="By Program Name" data={diversityData.byProgramName} />
            </div>
        </div>
    );
}