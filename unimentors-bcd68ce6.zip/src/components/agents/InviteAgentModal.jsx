import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { SendEmail } from '@/api/integrations';
import { Send, Check, AlertTriangle } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function InviteAgentModal({ isOpen, onClose }) {
  const [email, setEmail] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendStatus, setSendStatus] = useState(null); // 'success', 'error'

  const handleSendInvite = async () => {
    if (!email) return;

    setIsSending(true);
    setSendStatus(null);

    try {
      const registrationLink = `${window.location.origin}${createPageUrl("AgentRegistration")}`;
      const subject = "Invitation to Join UniMentor Agent Portal";
      const body = `
        Hello,
        
        You have been invited to join the UniMentor Agent Portal to submit student applications.
        
        Please click the link below to register your agency:
        ${registrationLink}
        
        If you have any questions, please contact our support team.
        
        Best regards,
        The UniMentor Team
      `;

      await SendEmail({
        to: email,
        subject: subject,
        body: body
      });

      setSendStatus('success');
      setEmail('');
    } catch (error) {
      console.error("Failed to send invite:", error);
      setSendStatus('error');
    }

    setIsSending(false);
  };
  
  const handleClose = () => {
      setSendStatus(null);
      setEmail('');
      onClose();
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="neumorphic rounded-2xl max-w-md mx-auto fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <DialogHeader>
          <DialogTitle className="text-neumorphic text-xl">Invite a New Agent</DialogTitle>
          <DialogDescription className="text-gray-500">
            Enter the agent's email address to send them a registration link.
          </DialogDescription>
        </DialogHeader>
        
        {!sendStatus ? (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="agent-email" className="text-neumorphic">Agent Email</Label>
              <Input
                id="agent-email"
                type="email"
                placeholder="agent@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="neumorphic-inset rounded-xl"
              />
            </div>
          </div>
        ) : sendStatus === 'success' ? (
          <div className="text-center py-8">
            <Check className="w-12 h-12 mx-auto text-green-500 mb-4" />
            <h3 className="font-bold text-neumorphic text-lg">Invite Sent!</h3>
            <p className="text-gray-500">The agent will receive an email shortly with registration instructions.</p>
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertTriangle className="w-12 h-12 mx-auto text-red-500 mb-4" />
            <h3 className="font-bold text-neumorphic text-lg">Error Sending Invite</h3>
            <p className="text-gray-500">Please check the email address and try again.</p>
          </div>
        )}
        
        <DialogFooter>
          {!sendStatus ? (
            <>
              <Button variant="ghost" onClick={handleClose} className="neumorphic rounded-xl">Cancel</Button>
              <Button onClick={handleSendInvite} disabled={isSending || !email} className="neumorphic rounded-xl bg-indigo-600 text-white">
                <Send className="w-4 h-4 mr-2" />
                {isSending ? 'Sending...' : 'Send Invite'}
              </Button>
            </>
          ) : (
            <Button onClick={handleClose} className="neumorphic rounded-xl w-full">Close</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}