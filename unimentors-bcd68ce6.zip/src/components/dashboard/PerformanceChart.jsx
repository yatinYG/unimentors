import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function PerformanceChart({ applications, isLoading }) {
  const prepareChartData = () => {
    if (!applications.length) return [];
    
    // Group applications by month
    const monthlyData = {};
    applications.forEach(app => {
      const month = format(new Date(app.created_date), 'MMM yyyy');
      if (!monthlyData[month]) {
        monthlyData[month] = { month, applications: 0, enrolled: 0 };
      }
      monthlyData[month].applications++;
      if (app.status === 'enrolled') {
        monthlyData[month].enrolled++;
      }
    });
    
    return Object.values(monthlyData).slice(-6); // Last 6 months
  };

  const chartData = prepareChartData();

  if (isLoading) {
    return (
      <Card className="neumorphic rounded-3xl">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-neumorphic">Performance Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-neumorphic">Performance Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" strokeOpacity={0.3} />
              <XAxis 
                dataKey="month" 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#6b7280', fontSize: 12 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#6b7280', fontSize: 12 }}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#f9fafb',
                  border: 'none',
                  borderRadius: '12px',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
                }}
              />
              <Area
                type="monotone"
                dataKey="applications"
                stroke="#667eea"
                fill="url(#colorApplications)"
                strokeWidth={3}
              />
              <Area
                type="monotone"
                dataKey="enrolled"
                stroke="#38a169"
                fill="url(#colorEnrolled)"
                strokeWidth={3}
              />
              <defs>
                <linearGradient id="colorApplications" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#667eea" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#667eea" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorEnrolled" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#38a169" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#38a169" stopOpacity={0}/>
                </linearGradient>
              </defs>
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}