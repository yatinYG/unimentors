import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { DollarSign, Clock, CheckCircle } from "lucide-react";

export default function CommissionSummary({ commissions, isLoading }) {
  const calculateSummary = () => {
    const pending = commissions.filter(c => c.status === 'pending').reduce((sum, c) => sum + c.commission_amount, 0);
    const approved = commissions.filter(c => c.status === 'approved').reduce((sum, c) => sum + c.commission_amount, 0);
    const paid = commissions.filter(c => c.status === 'paid').reduce((sum, c) => sum + c.commission_amount, 0);
    
    return { pending, approved, paid };
  };

  if (isLoading) {
    return (
      <Card className="neumorphic rounded-3xl">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-neumorphic">Commission Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 neumorphic-inset rounded-2xl">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-8 w-8 rounded-xl" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-6 w-20" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const summary = calculateSummary();

  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-neumorphic">Commission Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 neumorphic-inset rounded-2xl">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center">
                <Clock className="w-4 h-4 text-white" />
              </div>
              <span className="font-medium text-neumorphic">Pending</span>
            </div>
            <span className="font-bold text-lg text-neumorphic">${summary.pending.toLocaleString()}</span>
          </div>

          <div className="flex items-center justify-between p-4 neumorphic-inset rounded-2xl">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <span className="font-medium text-neumorphic">Approved</span>
            </div>
            <span className="font-bold text-lg text-neumorphic">${summary.approved.toLocaleString()}</span>
          </div>

          <div className="flex items-center justify-between p-4 neumorphic-inset rounded-2xl">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
                <DollarSign className="w-4 h-4 text-white" />
              </div>
              <span className="font-medium text-neumorphic">Paid</span>
            </div>
            <span className="font-bold text-lg text-neumorphic">${summary.paid.toLocaleString()}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}