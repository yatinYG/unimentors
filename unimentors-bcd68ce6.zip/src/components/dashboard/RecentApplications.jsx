import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { FileText, Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react";

const statusConfig = {
  submitted: { icon: Clock, color: 'bg-yellow-100 text-yellow-800', label: 'Submitted' },
  under_review: { icon: AlertCircle, color: 'bg-blue-100 text-blue-800', label: 'Under Review' },
  approved: { icon: CheckCircle, color: 'bg-green-100 text-green-800', label: 'Approved' },
  rejected: { icon: XCircle, color: 'bg-red-100 text-red-800', label: 'Rejected' },
  enrolled: { icon: CheckCircle, color: 'bg-purple-100 text-purple-800', label: 'Enrolled' }
};

export default function RecentApplications({ applications, isLoading }) {
  if (isLoading) {
    return (
      <Card className="neumorphic rounded-3xl">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-neumorphic">Recent Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 neumorphic-inset rounded-2xl">
                <div className="flex items-center gap-4">
                  <Skeleton className="h-10 w-10 rounded-xl" />
                  <div>
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-neumorphic">Recent Applications</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {applications.slice(0, 5).map((application) => {
            const statusInfo = statusConfig[application.status] || statusConfig.submitted;
            const StatusIcon = statusInfo.icon;
            
            return (
              <div key={application.id} className="flex items-center justify-between p-4 neumorphic-inset rounded-2xl hover:shadow-lg transition-all duration-300">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 neumorphic rounded-xl flex items-center justify-center">
                    <FileText className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-neumorphic">{application.student_name}</p>
                    <p className="text-sm text-gray-500">{application.program_applied}</p>
                    <p className="text-xs text-gray-400">
                      {format(new Date(application.created_date), 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>
                <Badge className={`${statusInfo.color} border-0 rounded-xl px-3 py-1 font-medium`}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  {statusInfo.label}
                </Badge>
              </div>
            );
          })}
          {applications.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No applications submitted yet</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}