import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from 'react-router-dom';

export default function StatsCards({ title, value, icon: Icon, gradient, isLoading, linkTo }) {
  if (isLoading) {
    return (
      <Card className="neumorphic rounded-3xl overflow-hidden">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <Skeleton className="h-4 w-20" />
              <Skeleton className="h-8 w-16" />
            </div>
            <Skeleton className="h-12 w-12 rounded-2xl" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const CardComponent = ({ children }) => {
    if (linkTo) {
      return (
        <Link to={linkTo}>
          <Card className="neumorphic rounded-3xl overflow-hidden hover:shadow-xl transition-all duration-500 group cursor-pointer">
            {children}
          </Card>
        </Link>
      );
    }
    return (
      <Card className="neumorphic rounded-3xl overflow-hidden hover:shadow-xl transition-all duration-500 group">
        {children}
      </Card>
    );
  };

  return (
    <CardComponent>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600 mb-2">{title}</p>
            <p className="text-2xl font-bold text-neumorphic group-hover:scale-105 transition-transform duration-300">
              {value}
            </p>
          </div>
          <div className={`w-12 h-12 rounded-2xl bg-gradient-to-r ${gradient} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
        </div>
      </CardContent>
    </CardComponent>
  );
}