import React, { useRef } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building, Upload } from 'lucide-react';
import { UploadFile } from '@/api/integrations';
import { Agent } from '@/api/entities';

export default function ProfileHeader({ agent, onPhotoUpload }) {
  const fileInputRef = useRef(null);

  const handlePhotoClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (file && agent) {
      try {
        const { file_url } = await UploadFile({ file });
        await Agent.update(agent.id, { profile_photo_url: file_url });
        if (onPhotoUpload) {
          onPhotoUpload(file_url);
        }
        // Refresh the page to show the new photo
        window.location.reload();
      } catch (error) {
        console.error("Error uploading photo:", error);
        alert("Failed to upload photo. Please try again.");
      }
    }
  };

  return (
    <Card className="neumorphic rounded-3xl overflow-hidden">
      <div className="h-32 bg-gradient-to-r from-indigo-200 to-purple-200" />
      <CardContent className="p-6 pt-0">
        <div className="flex items-end -mt-16">
          <div 
            className="relative w-32 h-32 rounded-full border-4 border-gray-200 bg-gray-300 flex items-center justify-center cursor-pointer group neumorphic"
            onClick={handlePhotoClick}
          >
            {agent?.profile_photo_url ? (
              <img src={agent.profile_photo_url} alt={agent.company_name} className="w-full h-full object-cover rounded-full" />
            ) : (
              <Building className="w-16 h-16 text-gray-500" />
            )}
            <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Upload className="w-8 h-8 text-white" />
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              accept="image/*"
            />
          </div>
          <div className="ml-6 flex-1">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-neumorphic">{agent?.company_name}</h2>
              <Badge className="bg-green-200 text-green-800 capitalize border-0">{agent?.status}</Badge>
            </div>
            <p className="text-gray-600">{agent?.contact_person}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}