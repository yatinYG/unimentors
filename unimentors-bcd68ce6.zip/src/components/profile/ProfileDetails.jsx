import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, MapPin, Globe, DollarSign } from "lucide-react";

export default function ProfileDetails({ agent }) {
  return (
    <Card className="neumorphic rounded-3xl h-full">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-neumorphic">Contact & Info</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 neumorphic-inset rounded-xl flex items-center justify-center flex-shrink-0">
            <Phone className="w-5 h-5 text-indigo-500"/>
          </div>
          <div>
            <p className="text-sm text-gray-500">Phone</p>
            <p className="font-medium text-neumorphic">{agent.phone}</p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 neumorphic-inset rounded-xl flex items-center justify-center flex-shrink-0">
            <MapPin className="w-5 h-5 text-green-500"/>
          </div>
          <div>
            <p className="text-sm text-gray-500">Address</p>
            <p className="font-medium text-neumorphic">{agent.address}</p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 neumorphic-inset rounded-xl flex items-center justify-center flex-shrink-0">
            <Globe className="w-5 h-5 text-blue-500"/>
          </div>
          <div>
            <p className="text-sm text-gray-500">Territories</p>
            <p className="font-medium text-neumorphic">{agent.territories?.join(', ')}</p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 neumorphic-inset rounded-xl flex items-center justify-center flex-shrink-0">
            <DollarSign className="w-5 h-5 text-purple-500"/>
          </div>
          <div>
            <p className="text-sm text-gray-500">Commission Rate</p>
            <p className="font-medium text-neumorphic">{agent.commission_rate}%</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}