import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { KeyRound, Users, ShieldCheck } from 'lucide-react';

export default function AccountManagementInfo() {
  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-neumorphic flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-indigo-500" />
          Account Management
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 text-sm text-gray-600">
        <div className="flex gap-4">
          <KeyRound className="w-5 h-5 mt-1 text-gray-500 flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-neumorphic">Password Security</h4>
            <p>Your account is secured by Google. To change your password, please update it in your Google Account settings.</p>
          </div>
        </div>
        <div className="flex gap-4">
          <Users className="w-5 h-5 mt-1 text-gray-500 flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-neumorphic">Team Access</h4>
            <p>To provide portal access to your team members, please have them sign up with their individual Google accounts.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}