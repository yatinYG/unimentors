import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";

export default function AgentSpecializations({ specializations }) {
  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-neumorphic">Specializations</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {specializations?.map((spec, index) => (
            <Badge key={index} className="bg-gray-300 text-gray-800 border-0 px-3 py-1 text-sm font-medium">
              <Star className="w-3 h-3 mr-2 text-yellow-500"/>
              {spec}
            </Badge>
          ))}
          {!specializations?.length && (
            <p className="text-sm text-gray-500">No specializations listed.</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}