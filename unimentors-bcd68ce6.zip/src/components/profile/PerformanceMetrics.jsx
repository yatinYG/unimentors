import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap, FileText, UserCheck, Percent } from "lucide-react";

const MetricItem = ({ icon: Icon, value, label, color }) => (
  <div className="neumorphic-inset rounded-2xl p-4 flex-1">
    <div className="flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center neumorphic`}>
        <Icon className={`w-6 h-6 ${color}`} />
      </div>
      <div>
        <p className="text-2xl font-bold text-neumorphic">{value}</p>
        <p className="text-sm text-gray-500">{label}</p>
      </div>
    </div>
  </div>
);

export default function PerformanceMetrics({ metrics }) {
  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-neumorphic">Performance Metrics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-4">
          <MetricItem 
            icon={Zap} 
            value={metrics?.leads_generated || 0} 
            label="Leads Generated" 
            color="text-blue-500" 
          />
          <MetricItem 
            icon={FileText} 
            value={metrics?.applications_submitted || 0} 
            label="Applications Submitted" 
            color="text-orange-500" 
          />
          <MetricItem 
            icon={UserCheck} 
            value={metrics?.enrollments_achieved || 0} 
            label="Enrollments Achieved" 
            color="text-green-500" 
          />
          <MetricItem 
            icon={Percent} 
            value={`${metrics?.conversion_rate?.toFixed(1) || 0}%`}
            label="Conversion Rate" 
            color="text-purple-500" 
          />
        </div>
      </CardContent>
    </Card>
  );
}