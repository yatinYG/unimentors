import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Save, X, Globe, Users } from "lucide-react";

const TERRITORIES = [
  'North America', 'South America', 'Europe', 'Asia Pacific', 'Middle East', 
  'Africa', 'Australia', 'Southeast Asia', 'East Asia', 'Central Asia'
];

const SPECIALIZATIONS = [
  'Computer Science', 'Business Administration', 'Engineering', 'Medicine', 
  'Law', 'Psychology', 'Education', 'Arts & Design', 'Economics', 
  'International Relations', 'Architecture', 'Nursing', 'Pharmacy'
];

export default function EditProfileForm({ agent, onUpdate, onCancel }) {
  const [formData, setFormData] = useState({
    company_name: agent.company_name || '',
    contact_person: agent.contact_person || '',
    phone: agent.phone || '',
    address: agent.address || '',
    territories: agent.territories || [],
    specializations: agent.specializations || []
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onUpdate(formData);
  };

  return (
    <Card className="neumorphic rounded-3xl">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-neumorphic">Edit Profile</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="text-neumorphic font-medium">Company Name</Label>
              <Input
                value={formData.company_name}
                onChange={(e) => handleInputChange('company_name', e.target.value)}
                className="neumorphic-inset rounded-xl border-0 bg-gray-200"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-neumorphic font-medium">Contact Person</Label>
              <Input
                value={formData.contact_person}
                onChange={(e) => handleInputChange('contact_person', e.target.value)}
                className="neumorphic-inset rounded-xl border-0 bg-gray-200"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-neumorphic font-medium">Phone</Label>
              <Input
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="neumorphic-inset rounded-xl border-0 bg-gray-200"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-neumorphic font-medium">Address</Label>
            <Textarea
              value={formData.address}
              onChange={(e) => handleInputChange('address', e.target.value)}
              className="neumorphic-inset rounded-xl border-0 bg-gray-200"
              rows={3}
            />
          </div>

          <div className="space-y-4">
            <Label className="text-neumorphic font-medium">Territories</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {TERRITORIES.map(territory => (
                <div
                  key={territory}
                  onClick={() => handleArrayToggle('territories', territory)}
                  className={`p-3 rounded-xl cursor-pointer transition-all duration-300 ${
                    formData.territories.includes(territory)
                      ? 'neumorphic-active text-white'
                      : 'neumorphic-inset hover:shadow-lg'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    <span className="text-sm font-medium">{territory}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <Label className="text-neumorphic font-medium">Specializations</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {SPECIALIZATIONS.map(spec => (
                <div
                  key={spec}
                  onClick={() => handleArrayToggle('specializations', spec)}
                  className={`p-3 rounded-xl cursor-pointer transition-all duration-300 ${
                    formData.specializations.includes(spec)
                      ? 'neumorphic-active text-white'
                      : 'neumorphic-inset hover:shadow-lg'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    <span className="text-sm font-medium">{spec}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-4 pt-6">
            <Button
              type="button"
              onClick={onCancel}
              className="neumorphic rounded-xl px-6 py-3 text-neumorphic"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button
              type="submit"
              className="neumorphic rounded-xl px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              Update Profile
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}