import { base44 } from './base44Client';


export const Agent = base44.entities.Agent;

export const Application = base44.entities.Application;

export const Document = base44.entities.Document;

export const Commission = base44.entities.Commission;



// auth sdk:
export const User = base44.auth;