import React, { useState, useEffect } from 'react';
import { Commission, Agent, User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { DollarSign } from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const statusConfig = {
    pending: { color: 'bg-yellow-200 text-yellow-800' },
    approved: { color: 'bg-blue-200 text-blue-800' },
    paid: { color: 'bg-green-200 text-green-800' },
    disputed: { color: 'bg-red-200 text-red-800' },
};

export default function Commissions() {
    const [commissions, setCommissions] = useState([]);
    const [currentAgent, setCurrentAgent] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const user = await User.me();
                if (!user.agent_code) {
                    navigate(createPageUrl("AgentRegistration"));
                    return;
                }
                
                const [agentData] = await Agent.filter({ agent_code: user.agent_code });
                if (!agentData) {
                    navigate(createPageUrl("AgentRegistration"));
                    return;
                }
                setCurrentAgent(agentData);
                
                const agentCommissions = await Commission.filter({ agent_id: agentData.id }, '-created_date');
                setCommissions(agentCommissions);
            } catch (error) {
                console.error('Error loading commissions:', error);
                navigate(createPageUrl("AgentRegistration"));
            }
            setIsLoading(false);
        };
        fetchData();
    }, [navigate]);
    
    const commissionTotals = commissions.reduce((acc, curr) => {
        const total = (curr.commission_amount || 0) + (curr.adjustment_amount || 0);
        acc.total += total;
        if(curr.status === 'paid') acc.paid += total;
        if(curr.status === 'pending' || curr.status === 'approved') acc.outstanding += total;
        return acc;
    }, { total: 0, paid: 0, outstanding: 0 });

    if (isLoading) return <Skeleton className="h-screen w-full" />;

    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-neumorphic mb-2">My Commissions</h1>
                    <p className="text-gray-600">View and track your commission earnings.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <Card className="neumorphic rounded-3xl p-6"><CardTitle>Total Commissions</CardTitle><p className="text-2xl font-bold">${commissionTotals.total.toLocaleString()}</p></Card>
                    <Card className="neumorphic rounded-3xl p-6"><CardTitle>Total Paid</CardTitle><p className="text-2xl font-bold">${commissionTotals.paid.toLocaleString()}</p></Card>
                    <Card className="neumorphic rounded-3xl p-6"><CardTitle>Outstanding</CardTitle><p className="text-2xl font-bold">${commissionTotals.outstanding.toLocaleString()}</p></Card>
                </div>

                <Card className="neumorphic rounded-3xl">
                    <CardHeader>
                        <CardTitle className="text-lg font-semibold text-neumorphic">Commission History</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Student</TableHead>
                                    <TableHead>Program</TableHead>
                                    <TableHead>Base Amount</TableHead>
                                    <TableHead>Rate</TableHead>
                                    <TableHead>Commission</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Date</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {commissions.map(c => (
                                    <TableRow key={c.id}>
                                        <TableCell className="font-medium">{c.student_name}</TableCell>
                                        <TableCell>{c.program}</TableCell>
                                        <TableCell>${(c.base_amount || 0).toLocaleString()}</TableCell>
                                        <TableCell>{c.commission_rate}%</TableCell>
                                        <TableCell className="font-bold">${((c.commission_amount || 0) + (c.adjustment_amount || 0)).toLocaleString()}</TableCell>
                                        <TableCell>
                                            <Badge className={`${statusConfig[c.status]?.color} capitalize`}>{c.status}</Badge>
                                        </TableCell>
                                        <TableCell className="text-sm text-gray-500">
                                            {format(new Date(c.created_date), 'MMM d, yyyy')}
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {/* Total Row */}
                                <TableRow className="border-t-2 border-gray-300 bg-gray-50">
                                    <TableCell className="font-bold">TOTAL</TableCell>
                                    <TableCell>-</TableCell>
                                    <TableCell className="font-bold">${commissions.reduce((sum, c) => sum + (c.base_amount || 0), 0).toLocaleString()}</TableCell>
                                    <TableCell>-</TableCell>
                                    <TableCell className="font-bold text-lg">${commissionTotals.total.toLocaleString()}</TableCell>
                                    <TableCell>-</TableCell>
                                    <TableCell>-</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                        {commissions.length === 0 && (
                            <div className="text-center py-16 text-gray-500">
                                <DollarSign className="w-16 h-16 mx-auto mb-4 opacity-50" />
                                <p className="text-lg">No commissions found.</p>
                                <p className="text-sm">Submit applications to start earning commissions.</p>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}