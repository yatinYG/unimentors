import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';
import UniversityDashboard from './UniversityDashboard';
import AgentDashboard from './AgentDashboard';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Dashboard() {
  const [userRole, setUserRole] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserRole = async () => {
      try {
        const user = await User.me();
        setUserRole(user.role);
      } catch (error) {
        // If user is not logged in, they might not have a role
        // For now, we can default to agent or redirect to login
        // Let's assume public users are potential agents
        navigate(createPageUrl('AgentRegistration'));
        console.error('Error fetching user:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUserRole();
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Skeleton className="h-8 w-1/3 mb-4" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Skeleton className="h-32 rounded-3xl" />
            <Skeleton className="h-32 rounded-3xl" />
            <Skeleton className="h-32 rounded-3xl" />
            <Skeleton className="h-32 rounded-3xl" />
          </div>
          <Skeleton className="h-96 rounded-3xl" />
        </div>
      </div>
    );
  }

  // default to user role if something went wrong
  const role = userRole || 'user';

  if (role === 'admin') {
    return <UniversityDashboard />;
  }
  
  return <AgentDashboard />;
}