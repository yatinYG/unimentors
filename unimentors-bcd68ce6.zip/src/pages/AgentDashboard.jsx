import React, { useState, useEffect } from "react";
import { Agent, Application, Commission, User } from "@/api/entities";
import StatsCards from "../components/dashboard/StatsCards";
import PerformanceChart from "../components/dashboard/PerformanceChart";
import RecentApplications from "../components/dashboard/RecentApplications";
import CommissionSummary from "../components/dashboard/CommissionSummary";
import { FileText, Calendar, DollarSign, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";

export default function AgentDashboard() {
  const [stats, setStats] = useState({ totalApplications: 0, pendingApplications: 0, totalCommissions: 0, conversionRate: 0 });
  const [applications, setApplications] = useState([]);
  const [commissions, setCommissions] = useState([]);
  const [currentAgent, setCurrentAgent] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      if (!user.agent_code) {
        navigate(createPageUrl("AgentRegistration"));
        return;
      }
      
      const [agentData] = await Agent.filter({ agent_code: user.agent_code });
      if (!agentData) {
        navigate(createPageUrl("AgentRegistration"));
        return;
      }
      setCurrentAgent(agentData);
      
      const agentId = agentData.id;
      const [agentApplications, agentCommissions] = await Promise.all([
        Application.filter({ agent_id: agentId }, '-created_date', 50),
        Commission.filter({ agent_id: agentId }, '-created_date', 50)
      ]);

      setApplications(agentApplications);
      setCommissions(agentCommissions);

      const totalApplications = agentApplications.length;
      const pendingApplications = agentApplications.filter(app => ['submitted', 'under_review'].includes(app.status)).length;
      const totalCommissions = agentCommissions.reduce((sum, comm) => sum + (comm.commission_amount || 0), 0);
      const enrolledApps = agentApplications.filter(app => app.status === 'enrolled').length;
      const conversionRate = totalApplications > 0 ? (enrolledApps / totalApplications) * 100 : 0;

      setStats({ totalApplications, pendingApplications, totalCommissions, conversionRate });
    } catch (error) {
      console.error('Error loading agent dashboard data:', error);
    }
    setIsLoading(false);
  };

  return (
    <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-neumorphic mb-2">Agent Dashboard</h1>
          {currentAgent ? (
            <p className="text-gray-600">Performance overview for {currentAgent.company_name}</p>
          ) : (
            <p className="text-gray-600">Monitor your recruitment performance and activities</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCards 
            title="My Applications" 
            value={stats.totalApplications} 
            icon={FileText} 
            gradient="from-blue-500 to-blue-600" 
            isLoading={isLoading} 
            linkTo={createPageUrl("MyApplications")}
          />
          <StatsCards 
            title="Pending Review" 
            value={stats.pendingApplications} 
            icon={Calendar} 
            gradient="from-orange-500 to-orange-600" 
            isLoading={isLoading} 
            linkTo={createPageUrl("MyApplications")}
          />
          <StatsCards 
            title="My Commissions" 
            value={`$${stats.totalCommissions.toLocaleString()}`} 
            icon={DollarSign} 
            gradient="from-green-500 to-green-600" 
            isLoading={isLoading} 
            linkTo={createPageUrl("MyCommissions")}
          />
          <StatsCards 
            title="Conversion Rate" 
            value={`${stats.conversionRate.toFixed(1)}%`} 
            icon={TrendingUp} 
            gradient="from-purple-500 to-purple-600" 
            isLoading={isLoading} 
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <PerformanceChart applications={applications} isLoading={isLoading} />
          </div>
          <div>
            <CommissionSummary commissions={commissions} isLoading={isLoading} />
          </div>
        </div>

        <div>
          <RecentApplications applications={applications} isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
}