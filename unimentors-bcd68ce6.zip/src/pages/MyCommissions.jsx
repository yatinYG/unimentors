import React from 'react';
import Commissions from './Commissions';

export default function MyCommissions() {
    return <Commissions />;
}