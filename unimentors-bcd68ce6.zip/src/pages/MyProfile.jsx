import React from 'react';
// I will reuse the AgentProfile component logic here. 
// Renaming the file to avoid conflicts and make the purpose clearer.
import AgentProfile from './AgentProfile';

export default function MyProfile() {
    return <AgentProfile />;
}