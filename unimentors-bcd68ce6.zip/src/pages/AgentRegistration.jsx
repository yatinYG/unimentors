import React, { useState } from "react";
import { Agent } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Building, Users, Globe, X } from "lucide-react";

const TERRITORIES = [
  'North America', 'South America', 'Europe', 'Asia Pacific', 'Middle East', 
  'Africa', 'Australia', 'Southeast Asia', 'East Asia', 'Central Asia'
];

const SPECIALIZATIONS = [
  'Computer Science', 'Business Administration', 'Engineering', 'Medicine', 
  'Law', 'Psychology', 'Education', 'Arts & Design', 'Economics', 
  'International Relations', 'Architecture', 'Nursing', 'Pharmacy'
];

export default function AgentRegistration() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    company_name: '',
    contact_person: '',
    email: '',
    phone: '',
    address: '',
    territories: [],
    specializations: [],
    commission_rate: 10,
    tier_level: 'bronze',
    status: 'pending'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Get current user info
      const currentUser = await User.me();
      
      // Generate agent code
      const agentCode = `AG${Date.now().toString().slice(-6)}`;
      
      const agentData = {
        ...formData,
        agent_code: agentCode,
        email: currentUser.email || formData.email,
        performance_metrics: {
          leads_generated: 0,
          applications_submitted: 0,
          enrollments_achieved: 0,
          conversion_rate: 0
        }
      };

      await Agent.create(agentData);
      
      // Update user profile to include agent info
      await User.updateMyUserData({
        agent_code: agentCode,
        company_name: formData.company_name,
        agent_status: 'pending'
      });
      
      setSubmitted(true);
    } catch (error) {
      console.error('Error creating agent profile:', error);
      alert('Error creating profile. Please try again.');
    }
    
    setIsSubmitting(false);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-200 flex items-center justify-center p-6">
        <Card className="neumorphic rounded-3xl max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 neumorphic rounded-2xl flex items-center justify-center mx-auto mb-6 bg-green-100">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-neumorphic mb-4">Registration Successful!</h2>
            <p className="text-gray-600 mb-6">
              Your agent profile has been submitted for review. You'll receive an email notification once approved.
            </p>
            <Button 
              onClick={() => window.location.href = '/'}
              className="neumorphic rounded-2xl px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white"
            >
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-200 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-neumorphic mb-2">Agent Registration</h1>
          <p className="text-gray-600">Join our network of education recruitment partners</p>
        </div>

        {/* Progress Steps */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-4">
            {[1, 2, 3].map(num => (
              <div key={num} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  step >= num 
                    ? 'neumorphic-active text-white' 
                    : 'neumorphic-inset text-gray-400'
                }`}>
                  {num}
                </div>
                {num < 3 && <div className="w-12 h-0.5 bg-gray-300 mx-2" />}
              </div>
            ))}
          </div>
        </div>

        <Card className="neumorphic rounded-3xl">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-neumorphic">
              {step === 1 && "Company Information"}
              {step === 2 && "Service Details"}
              {step === 3 && "Review & Submit"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              {step === 1 && (
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label className="text-neumorphic font-medium">Company Name *</Label>
                      <Input
                        value={formData.company_name}
                        onChange={(e) => handleInputChange('company_name', e.target.value)}
                        className="neumorphic-inset rounded-xl border-0 bg-gray-200"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-neumorphic font-medium">Contact Person *</Label>
                      <Input
                        value={formData.contact_person}
                        onChange={(e) => handleInputChange('contact_person', e.target.value)}
                        className="neumorphic-inset rounded-xl border-0 bg-gray-200"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-neumorphic font-medium">Email *</Label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="neumorphic-inset rounded-xl border-0 bg-gray-200"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-neumorphic font-medium">Phone Number *</Label>
                      <Input
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="neumorphic-inset rounded-xl border-0 bg-gray-200"
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-neumorphic font-medium">Business Address *</Label>
                    <Textarea
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      className="neumorphic-inset rounded-xl border-0 bg-gray-200"
                      rows={3}
                      required
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <Label className="text-neumorphic font-medium">Target Territories</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {TERRITORIES.map(territory => (
                        <div
                          key={territory}
                          onClick={() => handleArrayToggle('territories', territory)}
                          className={`p-3 rounded-xl cursor-pointer transition-all duration-300 ${
                            formData.territories.includes(territory)
                              ? 'neumorphic-active text-white'
                              : 'neumorphic-inset hover:shadow-lg'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <Globe className="w-4 h-4" />
                            <span className="text-sm font-medium">{territory}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Label className="text-neumorphic font-medium">Program Specializations</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {SPECIALIZATIONS.map(spec => (
                        <div
                          key={spec}
                          onClick={() => handleArrayToggle('specializations', spec)}
                          className={`p-3 rounded-xl cursor-pointer transition-all duration-300 ${
                            formData.specializations.includes(spec)
                              ? 'neumorphic-active text-white'
                              : 'neumorphic-inset hover:shadow-lg'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <Users className="w-4 h-4" />
                            <span className="text-sm font-medium">{spec}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <div className="neumorphic-inset rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-neumorphic mb-4 flex items-center gap-2">
                      <Building className="w-5 h-5" />
                      Company Information
                    </h3>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div><strong>Company:</strong> {formData.company_name}</div>
                      <div><strong>Contact:</strong> {formData.contact_person}</div>
                      <div><strong>Email:</strong> {formData.email}</div>
                      <div><strong>Phone:</strong> {formData.phone}</div>
                      <div className="md:col-span-2"><strong>Address:</strong> {formData.address}</div>
                    </div>
                  </div>

                  <div className="neumorphic-inset rounded-2xl p-6">
                    <h3 className="text-lg font-semibold text-neumorphic mb-4">Service Details</h3>
                    <div className="space-y-3">
                      <div>
                        <strong className="text-neumorphic">Territories:</strong>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {formData.territories.map(territory => (
                            <Badge key={territory} className="bg-blue-100 text-blue-800">
                              {territory}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <strong className="text-neumorphic">Specializations:</strong>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {formData.specializations.map(spec => (
                            <Badge key={spec} className="bg-purple-100 text-purple-800">
                              {spec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-between pt-6">
                {step > 1 && (
                  <Button
                    type="button"
                    onClick={() => setStep(step - 1)}
                    className="neumorphic rounded-xl px-6 py-3 text-neumorphic"
                  >
                    Previous
                  </Button>
                )}
                
                {step < 3 ? (
                  <Button
                    type="button"
                    onClick={() => setStep(step + 1)}
                    className="neumorphic rounded-xl px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white ml-auto"
                    disabled={
                      (step === 1 && (!formData.company_name || !formData.contact_person || !formData.email || !formData.phone || !formData.address)) ||
                      (step === 2 && (formData.territories.length === 0 || formData.specializations.length === 0))
                    }
                  >
                    Next
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="neumorphic rounded-xl px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white ml-auto"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Registration'}
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}