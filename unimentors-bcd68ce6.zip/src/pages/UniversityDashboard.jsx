import React, { useState, useEffect } from "react";
import { Agent, Application, Commission } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileText, DollarSign, TrendingUp, UserCheck, UserPlus } from "lucide-react";
import StatsCards from "../components/dashboard/StatsCards";
import PerformanceChart from "../components/dashboard/PerformanceChart";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function UniversityDashboard() {
    const [stats, setStats] = useState({
        totalAgents: 0,
        pendingAgents: 0,
        totalApplications: 0,
        totalCommissions: 0,
    });
    const [applications, setApplications] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadDashboardData();
    }, []);

    const loadDashboardData = async () => {
        setIsLoading(true);
        try {
            const [agentsData, applicationsData, commissionsData] = await Promise.all([
                Agent.list(),
                Application.list(),
                Commission.list()
            ]);

            const totalAgents = agentsData.length;
            const pendingAgents = agentsData.filter(agent => agent.status === 'pending').length;
            const totalApplications = applicationsData.length;
            const totalCommissions = commissionsData.reduce((sum, comm) => sum + (comm.commission_amount || 0), 0);
            
            setStats({ totalAgents, pendingAgents, totalApplications, totalCommissions });
            setApplications(applicationsData);
        } catch (error) {
            console.error('Error loading university dashboard data:', error);
        }
        setIsLoading(false);
    };

    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-neumorphic mb-2">University Dashboard</h1>
                    <p className="text-gray-600">Global overview of agent network and recruitment activities.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <StatsCards 
                        title="Total Agents" 
                        value={stats.totalAgents} 
                        icon={Users} 
                        gradient="from-cyan-500 to-blue-500" 
                        isLoading={isLoading} 
                        linkTo={createPageUrl("Agents")}
                    />
                    <StatsCards 
                        title="Pending Agents" 
                        value={stats.pendingAgents} 
                        icon={UserPlus} 
                        gradient="from-amber-500 to-orange-500" 
                        isLoading={isLoading} 
                        linkTo={createPageUrl("Agents")}
                    />
                    <StatsCards 
                        title="Total Applications" 
                        value={stats.totalApplications} 
                        icon={FileText} 
                        gradient="from-violet-500 to-fuchsia-500" 
                        isLoading={isLoading} 
                        linkTo={createPageUrl("UniversityApplications")}
                    />
                    <StatsCards 
                        title="Total Commissions Paid" 
                        value={`$${stats.totalCommissions.toLocaleString()}`} 
                        icon={DollarSign} 
                        gradient="from-lime-500 to-green-500" 
                        isLoading={isLoading} 
                        linkTo={createPageUrl("UniversityCommissions")}
                    />
                </div>

                <div className="grid lg:grid-cols-5 gap-6 mb-8">
                    <div className="lg:col-span-3">
                        <PerformanceChart applications={applications} isLoading={isLoading} />
                    </div>
                    <div className="lg:col-span-2">
                      <Card className="neumorphic rounded-3xl h-full">
                          <CardHeader>
                              <CardTitle className="text-lg font-semibold text-neumorphic">Quick Actions</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                              <Link to={createPageUrl('Agents')}>
                                  <div className="neumorphic-inset p-4 rounded-2xl hover:shadow-lg transition-all cursor-pointer">
                                      <h3 className="font-semibold text-neumorphic">Manage Agents</h3>
                                      <p className="text-sm text-gray-500">View, approve, and manage agent profiles.</p>
                                  </div>
                              </Link>
                              <Link to={createPageUrl('UniversityApplications')}>
                                  <div className="neumorphic-inset p-4 rounded-2xl hover:shadow-lg transition-all cursor-pointer">
                                      <h3 className="font-semibold text-neumorphic">Review Applications</h3>
                                      <p className="text-sm text-gray-500">Oversee all submitted student applications.</p>
                                  </div>
                              </Link>
                              <Link to={createPageUrl('UniversityCommissions')}>
                                  <div className="neumorphic-inset p-4 rounded-2xl hover:shadow-lg transition-all cursor-pointer">
                                      <h3 className="font-semibold text-neumorphic">Calculate Commissions</h3>
                                      <p className="text-sm text-gray-500">Manage and calculate agent commissions.</p>
                                  </div>
                              </Link>
                          </CardContent>
                      </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}