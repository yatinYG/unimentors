import React from 'react';
import Applications from './Applications';

export default function MyApplications() {
    return <Applications />;
}