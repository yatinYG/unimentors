
import React, { useState, useEffect } from 'react';
import { Agent } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Building, Mail, Phone, CheckCircle, Clock, XCircle, User, UserPlus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import InviteAgentModal from '../components/agents/InviteAgentModal';

const statusConfig = {
    active: { icon: CheckCircle, color: 'bg-green-200 text-green-800' },
    pending: { icon: Clock, color: 'bg-yellow-200 text-yellow-800' },
    suspended: { icon: XCircle, color: 'bg-red-200 text-red-800' },
    inactive: { icon: User, color: 'bg-gray-200 text-gray-800' }
};

const AgentCard = ({ agent }) => {
    const statusInfo = statusConfig[agent.status] || statusConfig.inactive;
    return (
        <Link to={createPageUrl(`AgentDetail?id=${agent.id}`)}>
            <div className="neumorphic-inset rounded-2xl p-4 hover:shadow-lg transition-all duration-300">
                <div className="flex justify-between items-start">
                    <h3 className="font-bold text-neumorphic text-lg">{agent.company_name}</h3>
                    <Badge className={`${statusInfo.color} border-0 capitalize`}>
                        <statusInfo.icon className="w-3 h-3 mr-1" />
                        {agent.status}
                    </Badge>
                </div>
                <p className="text-sm text-gray-600">{agent.contact_person}</p>
                <div className="mt-3 pt-3 border-t border-gray-300 flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
                    <div className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" /> {agent.email}</div>
                    <div className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" /> {agent.phone}</div>
                </div>
            </div>
        </Link>
    );
};

export default function Agents() {
    const [agents, setAgents] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isInviteModalOpen, setInviteModalOpen] = useState(false);

    useEffect(() => {
        const fetchAgents = async () => {
            setIsLoading(true);
            const data = await Agent.list();
            setAgents(data);
            setIsLoading(false);
        };
        fetchAgents();
    }, []);

    const filteredAgents = (status) => agents.filter(agent => agent.status === status);

    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h1 className="text-3xl font-bold text-neumorphic mb-2">Agent Management</h1>
                    <p className="text-gray-600">View, approve, and manage all recruitment partners.</p>
                  </div>
                  <Button onClick={() => setInviteModalOpen(true)} className="neumorphic rounded-xl px-4 py-2 flex items-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
                    <UserPlus className="w-5 h-5" />
                    Invite Agent
                  </Button>
                </div>

                <Card className="neumorphic rounded-3xl">
                    <CardContent className="p-6">
                        <Tabs defaultValue="active" className="w-full">
                            <TabsList className="grid w-full grid-cols-3 neumorphic-inset p-1 rounded-2xl">
                                <TabsTrigger value="active" className="neumorphic-tab-trigger">Active</TabsTrigger>
                                <TabsTrigger value="pending" className="neumorphic-tab-trigger">Pending</TabsTrigger>
                                <TabsTrigger value="suspended" className="neumorphic-tab-trigger">Suspended</TabsTrigger>
                            </TabsList>
                            <TabsContent value="active" className="mt-6">
                                <div className="space-y-4">
                                    {isLoading ? <Skeleton className="h-24 w-full" /> : filteredAgents('active').map(agent => <AgentCard key={agent.id} agent={agent} />)}
                                </div>
                            </TabsContent>
                            <TabsContent value="pending" className="mt-6">
                                <div className="space-y-4">
                                    {isLoading ? <Skeleton className="h-24 w-full" /> : filteredAgents('pending').map(agent => <AgentCard key={agent.id} agent={agent} />)}
                                </div>
                            </TabsContent>
                            <TabsContent value="suspended" className="mt-6">
                                <div className="space-y-4">
                                    {isLoading ? <Skeleton className="h-24 w-full" /> : filteredAgents('suspended').map(agent => <AgentCard key={agent.id} agent={agent} />)}
                                </div>
                            </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            </div>
            <InviteAgentModal isOpen={isInviteModalOpen} onClose={() => setInviteModalOpen(false)} />
            <style>{`
                .neumorphic-tab-trigger[data-state="active"] {
                    background: var(--neumorphic-bg);
                    box-shadow: 4px 4px 8px var(--neumorphic-dark), -4px -4px 8px var(--neumorphic-light);
                    color: var(--neumorphic-accent);
                }
                .neumorphic-tab-trigger {
                    border-radius: 1rem;
                }
            `}</style>
        </div>
    );
}
