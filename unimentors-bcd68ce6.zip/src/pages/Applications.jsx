import React, { useState, useEffect } from 'react';
import { Application, Agent, User } from '@/api/entities';
import ApplicationList from '../components/applications/ApplicationList';
import ApplicationFilters from '../components/applications/ApplicationFilters';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ImportApplications from "../components/applications/ImportApplications";
import { List, Upload } from 'lucide-react';

export default function Applications() {
  const [applications, setApplications] = useState([]);
  const [allApplications, setAllApplications] = useState([]);
  const [currentAgent, setCurrentAgent] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: 'all',
    program: 'all'
  });
  const navigate = useNavigate();

  const loadAgentData = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      if (!user.agent_code) {
        navigate(createPageUrl("AgentRegistration"));
        return;
      }
      
      const [agentData] = await Agent.filter({ agent_code: user.agent_code });
      if (!agentData) {
        navigate(createPageUrl("AgentRegistration"));
        return;
      }
      setCurrentAgent(agentData);
      
      const agentApplications = await Application.filter({ agent_id: agentData.id }, '-created_date');
      setAllApplications(agentApplications);
      setApplications(agentApplications);
    } catch (error) {
      console.error('Error loading agent applications:', error);
      // Redirect to registration on error, as it's likely a profile issue
      navigate(createPageUrl("AgentRegistration"));
    }
    setIsLoading(false);
  };
  
  useEffect(() => {
    loadAgentData();
  }, []);

  useEffect(() => {
    let filtered = [...allApplications];
    if (filters.status !== 'all') {
      filtered = filtered.filter(app => app.status === filters.status);
    }
    if (filters.program !== 'all') {
      filtered = filtered.filter(app => app.program_applied === filters.program);
    }
    setApplications(filtered);
  }, [filters, allApplications]);

  return (
    <div className="p-6 space-y-6 bg-gray-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-neumorphic mb-2">Student Applications</h1>
          <p className="text-gray-600">Manage, submit, and import student applications.</p>
        </div>

        <Tabs defaultValue="my-applications" className="w-full">
            <TabsList className="grid w-full grid-cols-2 neumorphic-inset p-1 rounded-2xl mb-6">
                <TabsTrigger value="my-applications" className="neumorphic-tab-trigger flex items-center gap-2">
                  <List className="w-4 h-4"/>
                  My Applications
                </TabsTrigger>
                <TabsTrigger value="import" className="neumorphic-tab-trigger flex items-center gap-2">
                  <Upload className="w-4 h-4"/>
                  Import Applications
                </TabsTrigger>
            </TabsList>
            <TabsContent value="my-applications">
                <div className="space-y-6">
                    <ApplicationFilters 
                      filters={filters}
                      onFiltersChange={setFilters}
                      applications={allApplications}
                    />
                    <ApplicationList 
                      applications={applications}
                      isLoading={isLoading}
                      onUpdate={loadAgentData}
                      currentAgent={currentAgent}
                    />
                </div>
            </TabsContent>
            <TabsContent value="import">
                <ImportApplications currentAgent={currentAgent} onImportComplete={loadAgentData} />
            </TabsContent>
        </Tabs>
      </div>
      <style>{`
          .neumorphic-tab-trigger[data-state="active"] {
              background: var(--neumorphic-bg);
              box-shadow: 4px 4px 8px var(--neumorphic-dark), -4px -4px 8px var(--neumorphic-light);
              color: var(--neumorphic-accent);
          }
          .neumorphic-tab-trigger {
              border-radius: 1rem;
          }
      `}</style>
    </div>
  );
}