
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  FolderOpen, 
  DollarSign, 
  BookOpen,
  GraduationCap,
  Briefcase,
  GitPullRequest,
  BarChart3,
  Settings,
  LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

// Navigation items for agent users
const agentNavItems = [
  { title: "Dashboard", url: createPageUrl("AgentDashboard"), icon: LayoutDashboard },
  { title: "My Profile", url: createPageUrl("MyProfile"), icon: Users },
  { title: "My Applications", url: createPageUrl("MyApplications"), icon: FileText },
  { title: "My Commissions", url: createPageUrl("MyCommissions"), icon: DollarSign },
  { title: "Documents", url: createPageUrl("Documents"), icon: FolderOpen },
  { title: "Training", url: createPageUrl("Training"), icon: BookOpen },
];

// Navigation items for admin (university) users
const adminNavItems = [
  { title: "Dashboard", url: createPageUrl("UniversityDashboard"), icon: LayoutDashboard },
  { title: "Agents", url: createPageUrl("Agents"), icon: Briefcase },
  { title: "Applications", url: createPageUrl("UniversityApplications"), icon: GitPullRequest },
  { title: "Commissions", url: createPageUrl("UniversityCommissions"), icon: DollarSign },
  { title: "Analytics", url: createPageUrl("Analytics"), icon: BarChart3 },
  { title: "Documents", url: createPageUrl("Documents"), icon: FolderOpen },
  { title: "Training", url: createPageUrl("Training"), icon: BookOpen },
];

// Reusable component to render navigation menu
const NavMenu = ({ items }) => {
  const location = useLocation();
  return (
    <SidebarMenu className="space-y-2">
      {items.map((item) => (
        <SidebarMenuItem key={item.title}>
          <SidebarMenuButton 
            asChild 
            className={`
              rounded-xl p-3 transition-all duration-300 
              ${location.pathname === item.url 
                ? 'neumorphic-active' 
                : 'neumorphic hover:shadow-lg'
              }
            `}
          >
            <Link to={item.url} className="flex items-center gap-3">
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.title}</span>
            </Link>
          </SidebarMenuButton>
        </SidebarMenuItem>
      ))}
    </SidebarMenu>
  );
};

export default function Layout({ children, currentPageName }) {
  const [currentUser, setCurrentUser] = React.useState(null); 

  React.useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        console.error('Error fetching user:', error);
      }
    };
    fetchUser();
  }, []);

  const handleLogout = async () => {
    try {
      await User.logout();
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  // Function to get the agent registration link
  const getRegistrationLink = () => {
    const baseUrl = window.location.origin;
    return `${baseUrl}${createPageUrl("AgentRegistration")}`;
  };

  // Determine navigation items and portal name based on user role
  const navItems = currentUser?.role === 'admin' ? adminNavItems : agentNavItems;
  const portalName = currentUser?.role === 'admin' ? 'University Portal' : 'Agent Portal';

  return (
    <div className="min-h-screen bg-gray-200" style={{
      background: 'linear-gradient(135deg, #e0e0e0 0%, #f0f0f0 100%)'
    }}>
      <style>{`
        :root {
          --neumorphic-bg: #e0e0e0;
          --neumorphic-light: #ffffff;
          --neumorphic-dark: #bebebe;
          --neumorphic-text: #4a5568;
          --neumorphic-accent: #667eea;
        }
        
        .neumorphic {
          background: var(--neumorphic-bg);
          box-shadow: 8px 8px 16px var(--neumorphic-dark), -8px -8px 16px var(--neumorphic-light);
          border: none;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .neumorphic-inset {
          background: var(--neumorphic-bg);
          box-shadow: inset 4px 4px 8px var(--neumorphic-dark), inset -4px -4px 8px var(--neumorphic-light);
          border: none;
        }
        
        .neumorphic-pressed {
          box-shadow: inset 6px 6px 12px var(--neumorphic-dark), inset -6px -6px 12px var(--neumorphic-light);
          transform: scale(0.98);
        }
        
        .neumorphic:hover {
          box-shadow: 12px 12px 20px var(--neumorphic-dark), -12px -12px 20px var(--neumorphic-light);
          transform: translateY(-2px);
        }
        
        .neumorphic-active {
          background: linear-gradient(145deg, #667eea, #764ba2);
          box-shadow: 4px 4px 8px var(--neumorphic-dark), -4px -4px 8px var(--neumorphic-light);
          color: white;
        }
        
        .text-neumorphic {
          color: var(--neumorphic-text);
        }
        
        .sidebar-neumorphic {
          background: var(--neumorphic-bg);
          box-shadow: 4px 0 16px var(--neumorphic-dark);
          border: none;
        }
      `}</style>
      
      <SidebarProvider>
        <div className="flex w-full min-h-screen">
          <Sidebar className="sidebar-neumorphic border-0">
            <SidebarHeader className="p-6 border-0">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 neumorphic rounded-2xl flex items-center justify-center">
                  <GraduationCap className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <h2 className="font-bold text-lg text-neumorphic">UniMentor</h2>
                  <p className="text-xs text-gray-500">{portalName}</p>
                </div>
              </div>
            </SidebarHeader>
            
            <SidebarContent className="px-4">
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2 py-3">
                  Navigation
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <NavMenu items={navItems} /> 
                </SidebarGroupContent>
              </SidebarGroup>

              {currentUser?.role !== 'admin' && ( 
                <SidebarGroup>
                  <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-2 py-3">
                    Quick Actions
                  </SidebarGroupLabel>
                  <SidebarGroupContent>
                    <div className="px-3 py-2">
                      <div className="neumorphic-inset rounded-2xl p-4">
                        <h3 className="font-semibold text-sm text-neumorphic mb-2">Invite New Agent</h3>
                        <p className="text-xs text-gray-500 mb-3">Share this registration link:</p>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={getRegistrationLink()}
                            readOnly
                            className="text-xs bg-gray-200 border-0 rounded-lg p-2 flex-1 neumorphic-inset"
                          />
                          <Button
                            size="sm"
                            onClick={() => navigator.clipboard.writeText(getRegistrationLink())}
                            className="neumorphic rounded-lg px-2 py-1 text-xs"
                          >
                            Copy
                          </Button>
                        </div>
                      </div>
                    </div>
                  </SidebarGroupContent>
                </SidebarGroup>
              )}
            </SidebarContent>

            <SidebarFooter className="p-6 border-0">
              <div className="neumorphic-inset rounded-2xl p-4">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-3 w-full text-left hover:opacity-80 transition-opacity">
                      <div className="w-10 h-10 neumorphic rounded-full flex items-center justify-center">
                        <span className="text-indigo-600 font-semibold text-sm">
                          {currentUser?.full_name?.charAt(0) || 'U'}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-neumorphic text-sm truncate">
                          {currentUser?.full_name || 'User'}
                        </p>
                        <p className="text-xs text-gray-500 truncate">
                          {currentUser?.company_name || currentUser?.email}
                        </p>
                      </div>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 neumorphic rounded-xl" align="end" forceMount>
                    <DropdownMenuItem asChild>
                      <Link to={createPageUrl("MyProfile")} className="flex items-center gap-2">
                        <Settings className="w-4 h-4" />
                        Profile Settings
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-red-600">
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col">
            <header className="bg-gray-200 p-4 md:hidden">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="neumorphic p-2 rounded-xl hover:shadow-lg transition-all duration-300" />
                <h1 className="text-xl font-bold text-neumorphic">UniMentor Portal</h1>
              </div>
            </header>

            <div className="flex-1 overflow-auto">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </div>
  );
}
