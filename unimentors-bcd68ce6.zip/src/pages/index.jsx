import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Applications from "./Applications";

import AgentProfile from "./AgentProfile";

import Documents from "./Documents";

import Commissions from "./Commissions";

import Training from "./Training";

import AgentRegistration from "./AgentRegistration";

import AgentDashboard from "./AgentDashboard";

import UniversityDashboard from "./UniversityDashboard";

import Agents from "./Agents";

import UniversityCommissions from "./UniversityCommissions";

import UniversityApplications from "./UniversityApplications";

import MyProfile from "./MyProfile";

import MyApplications from "./MyApplications";

import MyCommissions from "./MyCommissions";

import Documentation from "./Documentation";

import Analytics from "./Analytics";

import AgentDetail from "./AgentDetail";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Applications: Applications,
    
    AgentProfile: AgentProfile,
    
    Documents: Documents,
    
    Commissions: Commissions,
    
    Training: Training,
    
    AgentRegistration: AgentRegistration,
    
    AgentDashboard: AgentDashboard,
    
    UniversityDashboard: UniversityDashboard,
    
    Agents: Agents,
    
    UniversityCommissions: UniversityCommissions,
    
    UniversityApplications: UniversityApplications,
    
    MyProfile: MyProfile,
    
    MyApplications: MyApplications,
    
    MyCommissions: MyCommissions,
    
    Documentation: Documentation,
    
    Analytics: Analytics,
    
    AgentDetail: AgentDetail,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Applications" element={<Applications />} />
                
                <Route path="/AgentProfile" element={<AgentProfile />} />
                
                <Route path="/Documents" element={<Documents />} />
                
                <Route path="/Commissions" element={<Commissions />} />
                
                <Route path="/Training" element={<Training />} />
                
                <Route path="/AgentRegistration" element={<AgentRegistration />} />
                
                <Route path="/AgentDashboard" element={<AgentDashboard />} />
                
                <Route path="/UniversityDashboard" element={<UniversityDashboard />} />
                
                <Route path="/Agents" element={<Agents />} />
                
                <Route path="/UniversityCommissions" element={<UniversityCommissions />} />
                
                <Route path="/UniversityApplications" element={<UniversityApplications />} />
                
                <Route path="/MyProfile" element={<MyProfile />} />
                
                <Route path="/MyApplications" element={<MyApplications />} />
                
                <Route path="/MyCommissions" element={<MyCommissions />} />
                
                <Route path="/Documentation" element={<Documentation />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/AgentDetail" element={<AgentDetail />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}