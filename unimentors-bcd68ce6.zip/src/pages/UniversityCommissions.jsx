import React, { useState, useEffect } from 'react';
import { Commission, Agent } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { DollarSign, Percent } from 'lucide-react';
import { format } from 'date-fns';

const statusConfig = {
    pending: { color: 'bg-yellow-200 text-yellow-800' },
    approved: { color: 'bg-blue-200 text-blue-800' },
    paid: { color: 'bg-green-200 text-green-800' },
    disputed: { color: 'bg-red-200 text-red-800' },
};

export default function UniversityCommissions() {
    const [commissions, setCommissions] = useState([]);
    const [agents, setAgents] = useState([]);
    const [filteredCommissions, setFilteredCommissions] = useState([]);
    const [selectedAgent, setSelectedAgent] = useState('all');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            const [commsData, agentsData] = await Promise.all([
                Commission.list('-created_date'),
                Agent.list()
            ]);
            setCommissions(commsData);
            setFilteredCommissions(commsData);
            setAgents(agentsData);
            setIsLoading(false);
        };
        fetchData();
    }, []);

    useEffect(() => {
        if (selectedAgent === 'all') {
            setFilteredCommissions(commissions);
        } else {
            setFilteredCommissions(commissions.filter(c => c.agent_id === selectedAgent));
        }
    }, [selectedAgent, commissions]);

    const handleCommissionUpdate = async (id, field, value) => {
        const commission = commissions.find(c => c.id === id);
        if (commission) {
            let numValue = parseFloat(value);
            if(isNaN(numValue)) numValue = 0;

            let finalCommission = commission.base_amount * (commission.commission_rate / 100);

            if(field === 'adjustment_amount'){
                finalCommission += numValue
            } else {
                finalCommission += commission.adjustment_amount;
            }

            await Commission.update(id, { [field]: value, commission_amount: finalCommission });
            
            // Refresh local state
            const updatedCommissions = commissions.map(c => 
                c.id === id ? { ...c, [field]: value, commission_amount: finalCommission } : c
            );
            setCommissions(updatedCommissions);
        }
    };
    
    const commissionTotals = filteredCommissions.reduce((acc, curr) => {
        const total = (curr.commission_amount || 0) + (curr.adjustment_amount || 0);
        acc.total += total;
        if(curr.status === 'paid') acc.paid += total;
        if(curr.status === 'pending' || curr.status === 'approved') acc.outstanding += total;
        return acc;
    }, { total: 0, paid: 0, outstanding: 0 });

    if (isLoading) return <Skeleton className="h-screen w-full" />;

    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-neumorphic mb-2">Commission Management</h1>
                    <p className="text-gray-600">Calculate, track, and manage agent commissions.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <Card className="neumorphic rounded-3xl p-6"><CardTitle>Total Commissions</CardTitle><p className="text-2xl font-bold">${commissionTotals.total.toLocaleString()}</p></Card>
                    <Card className="neumorphic rounded-3xl p-6"><CardTitle>Total Paid</CardTitle><p className="text-2xl font-bold">${commissionTotals.paid.toLocaleString()}</p></Card>
                    <Card className="neumorphic rounded-3xl p-6"><CardTitle>Outstanding</CardTitle><p className="text-2xl font-bold">${commissionTotals.outstanding.toLocaleString()}</p></Card>
                </div>

                <Card className="neumorphic rounded-3xl">
                    <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle className="text-lg font-semibold text-neumorphic">Commission Calculator</CardTitle>
                        <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                            <SelectTrigger className="w-[250px] neumorphic-inset rounded-xl">
                                <SelectValue placeholder="Filter by Agent" />
                            </SelectTrigger>
                            <SelectContent className="neumorphic">
                                <SelectItem value="all">All Agents</SelectItem>
                                {agents.map(agent => <SelectItem key={agent.id} value={agent.id}>{agent.company_name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Student</TableHead>
                                    <TableHead>Base Amount</TableHead>
                                    <TableHead>Rate</TableHead>
                                    <TableHead>Adjustment</TableHead>
                                    <TableHead>Final Commission</TableHead>
                                    <TableHead>Status</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredCommissions.map(c => (
                                    <TableRow key={c.id}>
                                        <TableCell>{c.student_name}<br/><span className="text-xs text-gray-500">{c.program}</span></TableCell>
                                        <TableCell>${(c.base_amount || 0).toLocaleString()}</TableCell>
                                        <TableCell>{c.commission_rate}%</TableCell>
                                        <TableCell>
                                            <Input 
                                                type="number"
                                                defaultValue={c.adjustment_amount} 
                                                onBlur={(e) => handleCommissionUpdate(c.id, 'adjustment_amount', e.target.value)}
                                                className="w-24 neumorphic-inset rounded-lg"
                                            />
                                        </TableCell>
                                        <TableCell className="font-bold">${((c.commission_amount || 0) + (c.adjustment_amount || 0)).toLocaleString()}</TableCell>
                                        <TableCell>
                                            <Badge className={`${statusConfig[c.status]?.color} capitalize`}>{c.status}</Badge>
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {/* Total Row */}
                                <TableRow className="border-t-2 border-gray-300 bg-gray-50">
                                    <TableCell className="font-bold">TOTAL</TableCell>
                                    <TableCell className="font-bold">${filteredCommissions.reduce((sum, c) => sum + (c.base_amount || 0), 0).toLocaleString()}</TableCell>
                                    <TableCell>-</TableCell>
                                    <TableCell className="font-bold">${filteredCommissions.reduce((sum, c) => sum + (c.adjustment_amount || 0), 0).toLocaleString()}</TableCell>
                                    <TableCell className="font-bold text-lg">${commissionTotals.total.toLocaleString()}</TableCell>
                                    <TableCell>-</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}