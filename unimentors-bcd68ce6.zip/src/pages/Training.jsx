import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Video, FileText } from "lucide-react";

const trainingResources = [
  {
    title: "University Programs Overview",
    type: "Webinar Recording",
    icon: Video,
    description: "A deep dive into our flagship programs, admission requirements, and campus life."
  },
  {
    title: "Agent Portal Walkthrough",
    type: "Tutorial",
    icon: Video,
    description: "Learn how to effectively use all the features of this portal to manage your applications."
  },
  {
    title: "International Student Guide",
    type: "PDF Document",
    icon: FileText,
    description: "A comprehensive guide covering visa processes, accommodation, and cultural integration."
  }
];

export default function Training() {
    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-neumorphic mb-2">Training & Resources</h1>
                    <p className="text-gray-600">Materials to help you succeed in recruiting top students.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {trainingResources.map((resource, index) => {
                      const Icon = resource.icon;
                      return (
                        <Card key={index} className="neumorphic rounded-3xl p-6 h-full flex flex-col justify-between">
                            <div>
                                <div className="w-16 h-16 neumorphic-inset rounded-2xl flex items-center justify-center mb-4">
                                    <Icon className="w-8 h-8 text-indigo-500" />
                                </div>
                                <p className="text-sm font-medium text-indigo-600 mb-1">{resource.type}</p>
                                <h3 className="font-bold text-lg text-neumorphic mb-2">{resource.title}</h3>
                                <p className="text-sm text-gray-500">{resource.description}</p>
                            </div>
                        </Card>
                    )})}
                </div>
            </div>
        </div>
    );
}