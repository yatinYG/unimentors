
import React, { useState, useEffect } from "react";
import { Agent } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Users, Clock, Edit } from "lucide-react"; // Added Edit icon
import ProfileHeader from "../components/profile/ProfileHeader";
import ProfileDetails from "../components/profile/ProfileDetails";
import PerformanceMetrics from "../components/profile/PerformanceMetrics";
// Removed AgentSpecializations import
import EditProfileForm from "../components/profile/EditProfileForm";
import AccountManagementInfo from "../components/profile/AccountManagementInfo"; // Added new component import

export default function AgentProfile() {
  const [agent, setAgent] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchAgentProfile();
  }, []);

  const fetchAgentProfile = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      
      // Check if user has an agent code
      if (currentUser.agent_code) {
        const agents = await Agent.filter({ agent_code: currentUser.agent_code });
        if (agents.length > 0) {
          setAgent(agents[0]);
        } else {
          setError("Agent profile not found. Please contact support.");
        }
      } else {
        // User doesn't have an agent profile yet
        setError("no_profile");
      }
    } catch (e) {
      console.error("Failed to fetch agent profile:", e);
      setError("Could not load agent profile. Please try again later.");
    }
    setIsLoading(false);
  };

  const handleUpdateProfile = async (updatedData) => {
    if (!agent) return; // Added check
    try {
      await Agent.update(agent.id, updatedData);
      setAgent(prev => ({ ...prev, ...updatedData }));
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Error updating profile. Please try again.');
    }
  };

  const handlePhotoUpload = async (fileUrl) => { // New function
    await handleUpdateProfile({ profile_photo_url: fileUrl });
  };


  if (isLoading) {
    return (
      <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Skeleton className="h-10 w-1/3 mb-8" />
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <Skeleton className="h-48 w-full rounded-3xl" />
              <Skeleton className="h-64 w-full rounded-3xl" />
            </div>
            <div className="space-y-8">
              <Skeleton className="h-56 w-full rounded-3xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error === "no_profile") {
    return (
      <div className="p-6 bg-gray-200 min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-24 h-24 neumorphic rounded-3xl flex items-center justify-center mx-auto mb-6">
            <Users className="w-12 h-12 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-neumorphic mb-4">Create Your Agent Profile</h2>
          <p className="text-gray-600 mb-6">
            You need to create an agent profile to start submitting applications and earning commissions.
          </p>
          <Button
            onClick={() => navigate(createPageUrl("AgentRegistration"))}
            className="neumorphic rounded-2xl px-8 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white"
          >
            Create Agent Profile
          </Button>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-gray-200 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-neumorphic mb-4">Error</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button
            onClick={fetchAgentProfile}
            className="neumorphic rounded-2xl px-6 py-3"
          >
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  if (agent?.status === 'pending') {
    return (
      <div className="p-6 bg-gray-200 min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-24 h-24 neumorphic rounded-3xl flex items-center justify-center mx-auto mb-6 bg-yellow-100">
            <Clock className="w-12 h-12 text-yellow-600" />
          </div>
          <h2 className="text-2xl font-bold text-neumorphic mb-4">Profile Under Review</h2>
          <p className="text-gray-600 mb-6">
            Your agent profile is currently being reviewed by our team. You'll receive an email notification once approved.
          </p>
          <div className="neumorphic-inset rounded-2xl p-4 text-left">
            <h3 className="font-semibold text-neumorphic mb-2">Profile Details:</h3>
            <p className="text-sm text-gray-600">Company: {agent.company_name}</p>
            <p className="text-sm text-gray-600">Contact: {agent.contact_person}</p>
            <p className="text-sm text-gray-600">Email: {agent.email}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-neumorphic mb-2">Agent Profile</h1>
            <p className="text-gray-600">Manage your company information and view performance</p>
          </div>
          <Button
            onClick={() => setIsEditing(!isEditing)}
            className="neumorphic rounded-2xl px-6 py-3 hover:shadow-lg transition-all duration-300 flex items-center gap-2" // Added flex items-center gap-2 and icon
          >
            <Edit className="w-4 h-4"/> {/* Added Edit icon */}
            {isEditing ? 'Cancel Edit' : 'Edit Profile'}
          </Button>
        </div>
        
        {isEditing ? (
          <EditProfileForm
            agent={agent}
            onUpdate={handleUpdateProfile}
            onCancel={() => setIsEditing(false)}
          />
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <ProfileHeader agent={agent} onPhotoUpload={handlePhotoUpload} /> {/* Added onPhotoUpload prop */}
              <PerformanceMetrics metrics={agent.performance_metrics} />
            </div>
            <div className="space-y-8">
              <ProfileDetails agent={agent} />
              <AccountManagementInfo /> {/* Replaced AgentSpecializations with AccountManagementInfo */}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
