import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Book, Users, GraduationCap, Settings, FileText, DollarSign } from 'lucide-react';

export default function Documentation() {
  return (
    <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-neumorphic mb-2">EduConnect Portal Documentation</h1>
          <p className="text-gray-600">Complete guide for University staff and Recruitment Agents</p>
        </div>

        {/* Overview */}
        <Card className="neumorphic rounded-3xl mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Book className="w-6 h-6 text-indigo-600" />
              System Overview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-700">
              EduConnect is a comprehensive agent management portal designed for universities to manage their network of student recruitment agents. 
              The system provides separate interfaces for <strong>University Staff</strong> and <strong>Recruitment Agents</strong>, each tailored to their specific needs.
            </p>
            
            <div className="grid md:grid-cols-2 gap-6 mt-6">
              <div className="neumorphic-inset p-4 rounded-2xl">
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-blue-600" />
                  University Portal
                </h3>
                <ul className="text-sm space-y-2 text-gray-600">
                  <li>• Monitor all agent activities</li>
                  <li>• Approve/suspend agent registrations</li>
                  <li>• Track applications and commissions</li>
                  <li>• Manage documents and training materials</li>
                  <li>• Generate financial reports</li>
                </ul>
              </div>
              
              <div className="neumorphic-inset p-4 rounded-2xl">
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <Users className="w-5 h-5 text-green-600" />
                  Agent Portal
                </h3>
                <ul className="text-sm space-y-2 text-gray-600">
                  <li>• Submit student applications</li>
                  <li>• Track application status</li>
                  <li>• Access training materials</li>
                  <li>• View commission earnings</li>
                  <li>• Manage company profile</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* User Roles */}
        <Card className="neumorphic rounded-3xl mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Settings className="w-6 h-6 text-purple-600" />
              User Roles & Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-3">University Admin (role: 'admin')</h3>
                <div className="space-y-2">
                  <Badge className="bg-blue-100 text-blue-800">Full System Access</Badge>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p>• University Dashboard with global metrics</p>
                    <p>• Agent Management (approve/suspend agents)</p>
                    <p>• Application Oversight (all applications)</p>
                    <p>• Commission Calculator & Management</p>
                    <p>• Document Library Management</p>
                    <p>• Training Material Upload</p>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold mb-3">Recruitment Agent (role: 'user')</h3>
                <div className="space-y-2">
                  <Badge className="bg-green-100 text-green-800">Limited Access</Badge>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p>• Agent Dashboard (personal metrics only)</p>
                    <p>• Profile Management</p>
                    <p>• Application Submission (students)</p>
                    <p>• Commission Tracking (own earnings)</p>
                    <p>• Document Access (view only)</p>
                    <p>• Training Materials Access</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Getting Started */}
        <Card className="neumorphic rounded-3xl mb-8">
          <CardHeader>
            <CardTitle>Getting Started - Complete Workflow</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              
              {/* Step 1 */}
              <div className="neumorphic-inset p-6 rounded-2xl">
                <h3 className="font-semibold text-lg mb-4 text-indigo-600">Step 1: University Setup</h3>
                <div className="space-y-3">
                  <p><strong>Create University Admin Account:</strong></p>
                  <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                    <li>Login with Google (first user becomes admin automatically)</li>
                    <li>Or manually set user role to 'admin' via Dashboard → Data → User</li>
                  </ul>
                  
                  <p><strong>Upload Initial Documents:</strong></p>
                  <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                    <li>Go to Documents page</li>
                    <li>Upload marketing materials, application forms, agreements</li>
                    <li>Categorize documents for easy agent access</li>
                  </ul>
                </div>
              </div>

              {/* Step 2 */}
              <div className="neumorphic-inset p-6 rounded-2xl">
                <h3 className="font-semibold text-lg mb-4 text-green-600">Step 2: Agent Onboarding</h3>
                <div className="space-y-3">
                  <p><strong>Share Registration Link:</strong></p>
                  <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                    <li>Copy agent registration link from sidebar</li>
                    <li>Send to potential recruitment partners</li>
                    <li>Link format: <code className="bg-gray-100 px-2 py-1 rounded">yourapp.com/AgentRegistration</code></li>
                  </ul>
                  
                  <p><strong>Agent Registration Process:</strong></p>
                  <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                    <li>Agent fills 3-step registration form</li>
                    <li>System generates unique agent code</li>
                    <li>Status set to 'pending' for university approval</li>
                  </ul>
                  
                  <p><strong>University Approval:</strong></p>
                  <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                    <li>Review agent in Agents → Pending tab</li>
                    <li>Click agent name to view full profile</li>
                    <li>Change status to 'active' to approve</li>
                  </ul>
                </div>
              </div>

              {/* Step 3 */}
              <div className="neumorphic-inset p-6 rounded-2xl">
                <h3 className="font-semibold text-lg mb-4 text-purple-600">Step 3: Daily Operations</h3>
                <div className="space-y-3">
                  <p><strong>Agent Activities:</strong></p>
                  <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                    <li>Login to agent dashboard</li>
                    <li>Submit student applications via Applications page</li>
                    <li>Track application status in real-time</li>
                    <li>Access training materials and documents</li>
                  </ul>
                  
                  <p><strong>University Management:</strong></p>
                  <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                    <li>Monitor all applications via University Applications</li>
                    <li>Update application statuses (approved/rejected/enrolled)</li>
                    <li>Calculate commissions automatically</li>
                    <li>Generate financial reports</li>
                  </ul>
                </div>
              </div>

            </div>
          </CardContent>
        </Card>

        {/* Features Guide */}
        <Card className="neumorphic rounded-3xl mb-8">
          <CardHeader>
            <CardTitle>Feature-by-Feature Guide</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              
              {/* Applications */}
              <div className="neumorphic-inset p-4 rounded-2xl">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Application Management
                </h3>
                <div className="text-sm space-y-2">
                  <p><strong>Agent View:</strong></p>
                  <ul className="list-disc list-inside text-gray-600 ml-2">
                    <li>Submit new applications</li>
                    <li>View only own applications</li>
                    <li>Edit pending applications</li>
                  </ul>
                  <p><strong>University View:</strong></p>
                  <ul className="list-disc list-inside text-gray-600 ml-2">
                    <li>See all applications from all agents</li>
                    <li>Filter by agent, status, program</li>
                    <li>Update application status</li>
                    <li>Commission auto-calculation on enrollment</li>
                  </ul>
                </div>
              </div>

              {/* Commissions */}
              <div className="neumorphic-inset p-4 rounded-2xl">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  Commission System
                </h3>
                <div className="text-sm space-y-2">
                  <p><strong>Automatic Calculation:</strong></p>
                  <ul className="list-disc list-inside text-gray-600 ml-2">
                    <li>Based on agent's commission rate</li>
                    <li>Triggered when status = 'enrolled'</li>
                    <li>Manual adjustments allowed</li>
                  </ul>
                  <p><strong>Status Tracking:</strong></p>
                  <ul className="list-disc list-inside text-gray-600 ml-2">
                    <li>Pending → Approved → Paid</li>
                    <li>Disputed for issues</li>
                    <li>Export to Excel/CSV</li>
                  </ul>
                </div>
              </div>

            </div>
          </CardContent>
        </Card>

        {/* Data Feeding */}
        <Card className="neumorphic rounded-3xl">
          <CardHeader>
            <CardTitle>How to Feed Sample Data</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-gray-700">To test the system with sample data:</p>
              
              <div className="neumorphic-inset p-4 rounded-2xl">
                <h3 className="font-semibold mb-3">Method 1: Use the UI (Recommended)</h3>
                <ol className="list-decimal list-inside text-sm text-gray-600 space-y-2">
                  <li>Go to <code className="bg-gray-100 px-2 py-1 rounded">/AgentRegistration</code> and create sample agents</li>
                  <li>Login as university admin and approve agents</li>
                  <li>Login as different agents and submit sample applications</li>
                  <li>As university admin, change application status to 'enrolled' to generate commissions</li>
                </ol>
              </div>
              
              <div className="neumorphic-inset p-4 rounded-2xl">
                <h3 className="font-semibold mb-3">Method 2: Direct Database Insert</h3>
                <ol className="list-decimal list-inside text-sm text-gray-600 space-y-2">
                  <li>Go to Dashboard → Data → Agent</li>
                  <li>Use "Insert Record" to add sample agents</li>
                  <li>Go to Dashboard → Data → Application</li>
                  <li>Add sample applications with agent_id from created agents</li>
                  <li>Go to Dashboard → Data → Commission</li>
                  <li>Add sample commission records</li>
                </ol>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mt-4">
                <p className="text-sm text-yellow-800">
                  <strong>Note:</strong> The system will automatically populate with sample data when you first access the dashboard. 
                  You can modify or add more data as needed for testing.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}