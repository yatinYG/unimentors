import React, { useState, useEffect } from 'react';
import { Agent, Application, Commission } from '@/api/entities';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import ProfileHeader from '../components/profile/ProfileHeader';
import ProfileDetails from '../components/profile/ProfileDetails';
import PerformanceMetrics from '../components/profile/PerformanceMetrics';

export default function AgentDetail() {
    const [agentId, setAgentId] = useState(null);
    const [agent, setAgent] = useState(null);
    const [applications, setApplications] = useState([]);
    const [commissions, setCommissions] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [notes, setNotes] = useState('');

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const id = params.get('id');
        if (id) {
            setAgentId(id);
        } else {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        if (agentId) {
            fetchAgentData();
        }
    }, [agentId]);

    const fetchAgentData = async () => {
        setIsLoading(true);
        try {
            const agentData = await Agent.get(agentId);
            setAgent(agentData);
            setNotes(agentData.notes || '');

            const [apps, comms] = await Promise.all([
                Application.filter({ agent_id: agentId }),
                Commission.filter({ agent_id: agentId })
            ]);
            setApplications(apps);
            setCommissions(comms);
        } catch (error) {
            console.error("Failed to fetch agent details:", error);
        }
        setIsLoading(false);
    };

    const handleUpdateNotes = async () => {
        if (!agentId) return;
        await Agent.update(agentId, { notes });
        alert('Notes updated successfully!');
    };

    const handleStatusChange = async (newStatus) => {
        if (!agentId) return;
        await Agent.update(agentId, { status: newStatus });
        fetchAgentData(); // Refresh data
    };
    
    if (isLoading) return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
          <div className="max-w-7xl mx-auto">
            <Skeleton className="h-48 w-full rounded-3xl mb-8" />
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <Skeleton className="h-64 w-full rounded-3xl" />
              </div>
              <div className="space-y-8">
                <Skeleton className="h-56 w-full rounded-3xl" />
              </div>
            </div>
          </div>
        </div>
      );

    if (!agent) return (
        <div className="p-6 bg-gray-200 min-h-screen flex items-center justify-center">
            <div className="text-center">
                <h2 className="text-2xl font-bold text-neumorphic mb-4">Agent Not Found</h2>
                <p className="text-gray-600">Could not find the specified agent. Please check the ID and try again.</p>
            </div>
        </div>
    );

    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                        <ProfileHeader agent={agent} onPhotoUpload={fetchAgentData} />
                        <PerformanceMetrics metrics={agent.performance_metrics} />
                        <Card className="neumorphic rounded-3xl">
                            <CardHeader>
                                <CardTitle className="text-lg font-semibold text-neumorphic">Submitted Applications ({applications.length})</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-2">
                                {applications.slice(0, 5).map(app => (
                                    <div key={app.id} className="neumorphic-inset p-3 rounded-xl text-sm">
                                        {app.student_name} - {app.program_applied} ({app.status})
                                    </div>
                                ))}
                                {applications.length === 0 && <p className="text-sm text-gray-500">No applications submitted yet.</p>}
                            </CardContent>
                        </Card>
                    </div>
                    <div className="space-y-8">
                        <ProfileDetails agent={agent} />
                         <Card className="neumorphic rounded-3xl">
                            <CardHeader>
                                <CardTitle className="text-lg font-semibold text-neumorphic">Internal Notes</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <Textarea
                                    value={notes}
                                    onChange={(e) => setNotes(e.target.value)}
                                    className="neumorphic-inset rounded-xl border-0 bg-gray-200"
                                    rows={5}
                                    placeholder="Add internal comments here..."
                                />
                                <Button onClick={handleUpdateNotes} className="neumorphic rounded-xl w-full">Save Notes</Button>
                            </CardContent>
                        </Card>
                        <Card className="neumorphic rounded-3xl">
                            <CardHeader>
                                <CardTitle className="text-lg font-semibold text-neumorphic">Agent Status</CardTitle>
                            </CardHeader>
                            <CardContent className="flex flex-wrap gap-2">
                                <Button onClick={() => handleStatusChange('active')} disabled={agent.status === 'active'} className="neumorphic-active disabled:opacity-50">Activate</Button>
                                <Button onClick={() => handleStatusChange('suspended')} disabled={agent.status === 'suspended'} className="bg-red-500 text-white neumorphic">Suspend</Button>
                                <Button onClick={() => handleStatusChange('pending')} disabled={agent.status === 'pending'}>Set to Pending</Button>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}