import React, { useState, useEffect } from "react";
import { Application, Agent } from "@/api/entities";
import ApplicationList from "../components/applications/ApplicationList";
import ApplicationFilters from "../components/applications/ApplicationFilters";

export default function UniversityApplications() {
  const [applications, setApplications] = useState([]);
  const [allApplications, setAllApplications] = useState([]);
  const [agents, setAgents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: 'all',
    program: 'all',
    agent: 'all'
  });

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        const [applicationsData, agentsData] = await Promise.all([
          Application.list('-created_date'),
          Agent.list()
        ]);
        setAllApplications(applicationsData);
        setApplications(applicationsData);
        setAgents(agentsData);
      } catch (error) {
        console.error('Error loading data:', error);
      }
      setIsLoading(false);
    };
    loadData();
  }, []);

  useEffect(() => {
    let filtered = [...allApplications];
    if (filters.agent !== 'all') {
      filtered = filtered.filter(app => app.agent_id === filters.agent);
    }
    if (filters.status !== 'all') {
      filtered = filtered.filter(app => app.status === filters.status);
    }
    if (filters.program !== 'all') {
      filtered = filtered.filter(app => app.program_applied === filters.program);
    }
    setApplications(filtered);
  }, [filters, allApplications]);

  return (
    <div className="p-6 space-y-6 bg-gray-200 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-neumorphic mb-2">All Student Applications</h1>
          <p className="text-gray-600">Oversee and manage all applications from the agent network.</p>
        </div>
        
        <div className="space-y-6">
          <ApplicationFilters 
            filters={filters}
            onFiltersChange={setFilters}
            applications={allApplications}
            agents={agents}
            showAgentFilter={true}
            isUniversityView={true}
          />
          <ApplicationList 
            applications={applications}
            isLoading={isLoading}
            isUniversityView={true}
          />
        </div>
      </div>
    </div>
  );
}