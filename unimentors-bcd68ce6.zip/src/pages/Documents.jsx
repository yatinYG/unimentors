import React, { useState, useEffect } from "react";
import { Document as DocumentEntity } from "@/api/entities";
import { Skeleton } from "@/components/ui/skeleton";
import { Card } from "@/components/ui/card";
import { FileText } from "lucide-react";

export default function Documents() {
    const [documents, setDocuments] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchDocuments = async () => {
            setIsLoading(true);
            const docs = await DocumentEntity.list('-created_date');
            setDocuments(docs);
            setIsLoading(false);
        };
        fetchDocuments();
    }, []);

    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-neumorphic mb-2">Document Library</h1>
                    <p className="text-gray-600">Access marketing materials, forms, and agreements.</p>
                </div>
                
                {isLoading ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {Array(6).fill(0).map((_, i) => (
                           <Skeleton key={i} className="h-48 w-full rounded-3xl" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {documents.map(doc => (
                            <a href={doc.file_url} key={doc.id} target="_blank" rel="noopener noreferrer">
                                <Card className="neumorphic rounded-3xl p-6 h-full flex flex-col justify-between">
                                    <div>
                                        <div className="w-16 h-16 neumorphic-inset rounded-2xl flex items-center justify-center mb-4">
                                            <FileText className="w-8 h-8 text-indigo-500" />
                                        </div>
                                        <h3 className="font-bold text-lg text-neumorphic mb-2">{doc.title}</h3>
                                        <p className="text-sm text-gray-500 line-clamp-2">{doc.description}</p>
                                    </div>
                                    <div className="mt-4 text-xs text-gray-400">
                                        Version: {doc.version}
                                    </div>
                                </Card>
                            </a>
                        ))}
                    </div>
                )}
                 { !isLoading && documents.length === 0 && (
                     <div className="text-center py-16">
                        <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                        <p className="text-gray-500 text-lg">The document library is currently empty.</p>
                    </div>
                 )}
            </div>
        </div>
    );
}