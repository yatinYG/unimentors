import React, { useState, useEffect } from 'react';
import { Agent, Application } from '@/api/entities';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import ProcessingTimeAnalytics from '../components/analytics/ProcessingTimeAnalytics';
import DiversityAnalytics from '../components/analytics/DiversityAnalytics';
import AgentPerformanceAnalytics from '../components/analytics/AgentPerformanceAnalytics';

export default function Analytics() {
    const [applications, setApplications] = useState([]);
    const [agents, setAgents] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [appsData, agentsData] = await Promise.all([
                    Application.list(),
                    Agent.list()
                ]);
                setApplications(appsData);
                setAgents(agentsData);
            } catch (error) {
                console.error("Failed to fetch analytics data:", error);
            }
            setIsLoading(false);
        };
        fetchData();
    }, []);

    if (isLoading) {
        return (
            <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
                <div className="max-w-7xl mx-auto">
                    <Skeleton className="h-8 w-64 mb-8" />
                    <Skeleton className="h-12 w-full mb-4" />
                    <Skeleton className="h-96 w-full rounded-3xl" />
                </div>
            </div>
        );
    }
    
    return (
        <div className="p-6 space-y-8 bg-gray-200 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-neumorphic mb-2">Recruitment Analytics</h1>
                    <p className="text-gray-600">Insights into agent performance and application trends.</p>
                </div>
                
                <Card className="neumorphic rounded-3xl">
                    <CardContent className="p-6">
                        <Tabs defaultValue="performance" className="w-full">
                            <TabsList className="grid w-full grid-cols-3 neumorphic-inset p-1 rounded-2xl">
                                <TabsTrigger value="performance" className="neumorphic-tab-trigger">Agent Performance</TabsTrigger>
                                <TabsTrigger value="diversity" className="neumorphic-tab-trigger">Application Diversity</TabsTrigger>
                                <TabsTrigger value="processing" className="neumorphic-tab-trigger">Processing Time</TabsTrigger>
                            </TabsList>
                            <TabsContent value="performance" className="mt-6">
                                <AgentPerformanceAnalytics applications={applications} agents={agents} />
                            </TabsContent>
                            <TabsContent value="diversity" className="mt-6">
                                <DiversityAnalytics applications={applications} agents={agents} />
                            </TabsContent>
                            <TabsContent value="processing" className="mt-6">
                                <ProcessingTimeAnalytics applications={applications} agents={agents} />
                            </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}